<?php

declare(strict_types=1);

// Section header
$servicesHeader = [
  'subtitle'    => 'Who We Are',
  'title'       => 'Driving <span>Digital Impact</span> Through <span>Innovation</span>',
  'description' => <<<TEXT
At Neorotech, we are a team of technology strategists, engineers, and innovators dedicated to transforming ideas into impactful digital solutions, with a foundation rooted in academic excellence and hands-on industry expertise, we blend agility with deep technical insight to build secure, scalable, and future-ready products.
We harness the power of AI, cloud-native infrastructure, microservice architectures, and secure cross-platform systems to serve startups, enterprises, and growing businesses across diverse industries.
Our commitment to quality is unwavering, Leveraging industry-ing practices, advanced tools, and expert collaboration, we deliver seamless, high-performance solutions tailored to our clients’ evolving needs.
At the core of our approach is a deep focus on client success—we work as long-term partners, driving meaningful outcomes through innovation, integrity, and a relentless pursuit of excellence.
TEXT
];

// Services List
$servicesList = [
  [
    'title'       => 'Vision',
    'description' => 'To be the ing force in digital transformation—empowering businesses globally with innovative, scalable, and tailored technology solutions that drive growth, efficiency, and a better tomorrow.',
  ],
  [
    'title'       => 'Mission',
    'description' => 'To deliver custom software and transformative technologies that solve complex challenges and fuel long-term success—through expert collaboration, innovation, and a relentless pursuit of excellence.',
  ], 
  [
    'title'       => 'Core Strength',
    'description' => 'Driven by our people, expertise, and continuous learning, we foster a high-performance culture that delivers secure, intelligent, and scalable solutions for today and tomorrow.',
  ], 
];
?><section id="services" class="py-5 bg-primary" aria-labelledby="services-heading">
  <div class="container">

    <!-- Section Header -->
    <div class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <span class="sub-heading-title d-inline-block mb-2">
          <?= htmlspecialchars($servicesHeader['subtitle']) ?>
        </span>
        <h2 id="services-heading" class="heading-title my-3">
          <?= $servicesHeader['title'] ?>
        </h2>
        <p class="mx-auto text-start">
          <?= nl2br(htmlspecialchars($servicesHeader['description'])) ?>
        </p>
      </div>
    </div>

    <!-- Services Grid -->
    <div class="row g-4">
      <?php foreach ($servicesList as $index => $service): ?>
        <div class="col-12 col-sm-6 col-lg-4 d-flex" data-aos="zoom-in" data-aos-delay="<?= 100 * ($index + 1) ?>">
          <article class="card theme-card h-100 border-0 rounded-0 p-3 d-flex flex-column text-dark">
            <div class="card-body d-flex flex-column h-100">
              <h3 class="card-title h5 mb-2">
                <?= htmlspecialchars($service['title']) ?>
              </h3>
              <p class="card-text mb-0  lh-base text-start">
                <?= htmlspecialchars($service['description']) ?>
              </p>
            </div>
          </article>
        </div>

      <?php endforeach; ?>
    </div>

  </div>
</section>