<?php
$clientPartnerLogos = [
  '/assets/images/partner/01.png',
  '/assets/images/partner/02.png',
  '/assets/images/partner/03.png',
  '/assets/images/partner/04.png',
  '/assets/images/partner/05.png',
  '/assets/images/partner/06.png',
  '/assets/images/partner/07.png',
  '/assets/images/partner/08.png',
];
?>
<section id="partners" class="partners py-5" aria-labelledby="partnersHeading">
  <div class="container">

    <!-- Section Header -->
    <div class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <span class="sub-heading-title d-inline-block mb-2">
          <?= htmlspecialchars('Our Trusted Client') ?>
        </span>
        <h2 id="partnersHeading" class="heading-title my-3">
          <span>Trusted</span> By The Best <span>Agencies</span> In The <span>World</span>
        </h2>
      </div>
    </div>

    <!-- Scrolling Partner Logos Marquee -->
    <div class="marquee-wrapper overflow-hidden" data-aos="fade-up" data-aos-delay="100">
      <div class="marquee d-flex align-items-center" role="region" aria-label="Scrolling list of client partner logos">

        <!-- First Logo Set -->
        <div class="marquee-content d-flex flex-nowrap" aria-hidden="false">
          <?php foreach ($clientPartnerLogos as $index => $logoPath): ?>
            <div class="partner-logo mx-3 flex-shrink-0">
              <img
                src="<?= htmlspecialchars($logoPath) ?>"
                alt="Partner Logo <?= $index + 1 ?>"
                class="img-fluid"
                loading="lazy"
                width="120"
                height="60"
              >
            </div>
          <?php endforeach; ?>
        </div>

        <!-- Cloned Set for Seamless Loop -->
        <div class="marquee-content d-flex flex-nowrap" aria-hidden="true">
          <?php foreach ($clientPartnerLogos as $logoPath): ?>
            <div class="partner-logo mx-3 flex-shrink-0">
              <img
                src="<?= htmlspecialchars($logoPath) ?>"
                alt=""
                class="img-fluid"
                loading="lazy"
                width="120"
                height="60"
              >
            </div>
          <?php endforeach; ?>
        </div>

      </div>
    </div>

  </div>
</section>


