<?php 
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';

$slides = [
  [
    'image' => '/assets/images/slider/slide3.png',
    'mobileImage' => '/assets/images/slider/slide3-mobile.png',
    'subtitle' => 'Digital Empowering Growth with Us!',
    'title' => '<span>Transforming</span> Digital Concepts into <span>Robust</span> and <span>Profitable</span> Realities',
    'description' => 'Neorotech transforms strategic ideas into digital platforms that drive measurable growth, resilience, and sustained profitability.',
    'buttons' => [
      ['text' => 'Learn More', 'link' => '/about/index', 'icon' => 'fas fa-arrow-right-long']
    ]
  ],
      [
    'image' => '/assets/images/slider/slide4.png',
    'mobileImage' => '/assets/images/slider/slide4-mobile.png',
    'subtitle' => 'Empowering Growth with Neorotech!',
    'title' => 'We Delivers <span>Impact-Driven Solutions</span> for <span>Sustainable Business</span> Growth',
    'description' => 'We’ve developed impactful software that performs seamlessly and inspires confidence, Let’s explore your investment or quoting needs!',
    'buttons' => [
      ['text' => 'Learn More', 'link' => '/about/index', 'icon' => 'fas fa-arrow-right-long']
    ]
    ],
  
  [
    'image' => '/assets/images/slider/GenAI.png',
    'mobileImage' => '/assets/images/slider/GenAI.png',
    'subtitle' => 'Empowering Outcomes with Gen AI!',
    'title' => 'Recognized as an <span>emerging leader</span> in Gen AI consulting and <span>implementation</span>',
    'description' => 'We specialize in delivering contextualized Generative AI solutions designed to achieve measurable, real-world impact.',
    'buttons' => [
      ['text' => 'Learn More', 'link' => '/about/index', 'icon' => 'fas fa-arrow-right-long']
    ]
    ]
];
?>

<section id="hero" class="hero-section slide-bg">
  <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000" aria-label="Hero Carousel">

    <!-- Indicators -->
    <div class="carousel-indicators">
      <?php foreach ($slides as $i => $_): ?>
        <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="<?= $i ?>" class="<?= $i === 0 ? 'active' : '' ?>" <?= $i === 0 ? 'aria-current="true"' : '' ?> aria-label="Slide <?= $i + 1 ?>"></button>
      <?php endforeach; ?>
    </div>

    <!-- Slides -->
    <div class="carousel-inner">
      <?php foreach ($slides as $i => $slide):
        $isRight = $i % 2 !== 0;
        $justify = $isRight ? 'justify-content-end' : 'justify-content-start';
        $fadeAnim = $isRight ? 'fade-left' : 'fade-right';
      ?>
        <div class="carousel-item <?= $i === 0 ? 'active' : '' ?>">
          <div class="hero-single d-flex align-items-center min-vh-100 bg-cover position-relative text-white"
               data-aos="<?= $fadeAnim ?>"
               data-aos-duration="1000"
               data-mobile-bg="<?= htmlspecialchars($slide['mobileImage']) ?>"
               style="background-image: url('<?= htmlspecialchars($slide['image']) ?>');">
            <img class="d-none preload" src="<?= htmlspecialchars($slide['image']) ?>" alt="Slide <?= $i + 1 ?>" loading="lazy" />

            <div class="container">
              <div class="row <?= $justify ?> align-items-center">
                <div class="col-lg-8 col-md-12">
                  <div class="hero-content text-start" data-aos="fade-up" data-aos-delay="200">

                    <?php if (!empty($slide['subtitle'])): ?>
                      <p class="hero-sub-heading-title mb-2 fw-semibold text-uppercase"><?= htmlspecialchars($slide['subtitle']) ?></p>
                    <?php endif; ?>

                    <?php if (!empty($slide['title'])): ?>
                      <h1 class="hero-title mb-3"><?= $slide['title'] ?></h1>
                    <?php endif; ?>

                    <?php if (!empty($slide['description'])): ?>
                      <p class="insight-title mb-3" data-aos="fade-up" data-aos-delay="100">
                        <?= htmlspecialchars($slide['description']) ?>
                      </p>
                    <?php endif; ?>

                    <?php if (!empty($slide['buttons'])): ?>
                      <div class="hero-buttons d-flex gap-3 flex-wrap mt-3">
                        <?php foreach ($slide['buttons'] as $btn): ?>
                          <a href="<?= htmlspecialchars($btn['link']) ?>" class="btn theme-btn" aria-label="<?= htmlspecialchars($btn['text']) ?>">
                            <?= htmlspecialchars($btn['text']) ?>
                            <?php if (!empty($btn['icon'])): ?>
                              <i class="<?= htmlspecialchars($btn['icon']) ?>"></i>
                            <?php endif; ?>
                          </a>
                        <?php endforeach; ?>
                      </div>
                    <?php endif; ?>

                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Controls -->
    <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>

  </div>
</section>

<!-- CSS -->
<style>
  .hero-single {
    background-size: cover;
    background-position: center;
  }
</style>

<!-- JS -->
<script>
  document.addEventListener("DOMContentLoaded", function () {
    if (window.innerWidth <= 768) {
      document.querySelectorAll('.hero-single').forEach(el => {
        const mobileBg = el.dataset.mobileBg;
        if (mobileBg) {
          el.style.backgroundImage = `url('${mobileBg}')`;
        }
      });
    }
  });
</script>
