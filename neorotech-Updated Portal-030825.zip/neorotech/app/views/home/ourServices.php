<?php

declare(strict_types=1);

$ourServicesection = [
  'subtitle'    => 'Our Services',
  'title'       => 'Turning <span>Vision</span> into <span>Actionable</span>, <span>Scalable Digital Success</span>',
  'description' => <<<TEXT
At Neorotech, we engineer intelligent, future-ready software solutions that evolve alongside your business. As a full-spectrum technology partner, we combine cutting-edge innovation, deep technical expertise, and proven architectural principles to deliver impactful digital experiences—tailored to startups, scale-ups, and enterprises across industries.
Through our Advanced Technology Solutions™ and Core Business Services, we deliver AI-powered platforms, hyperautomation, IoT-enabled ecosystems, cloud modernization, and advanced cybersecurity frameworks—solutions that elevate enterprise performance and generate measurable business impact.
TEXT
];


$ourServices = [
  [
    'title' => 'Web Development',
    'text'  => 'We design and build high‑performance, secure, and scalable websites that serve as the foundation of your digital presence, from corporate portals to enterprise platforms, our solutions drive engagement and deliver results.',
    'link'  => '/service/web-development/'

  ],
  [
    'title' => 'UI/UX Design',
    'text'  => 'Our design experts craft intuitive and visually compelling interfaces that elevate user experience and strengthen brand identity, we combine creativity with strategy to create interfaces that convert visitors into loyal users.',
    'link'  => '/service/ui-ux-design/'
  ],
  [
    'title' => 'Mobile App Development',
    'text'  => 'Reach your audience anywhere, anytime with feature‑rich, cross‑platform mobile applications, we develop apps optimized for iOS and Android, ensuring seamless performance, strong security, and a user‑first experience.',
    'link'  => '/service/mobile-app-development/'
  ],
  [
    'title' => 'DevOps Solutions',
    'text'  => 'We bridge the gap between development and operations through streamlined workflows, automation, and continuous delivery and Our DevOps services accelerate deployment cycles and enhance operational efficiency.',
    'link'  => '/service/devops-strategy-assessment/'
  ],
  [
    'title' => 'AI and Data-Driven Solutions',
    'text'  => 'AI and Data-Driven Solutions combine machine learning, artificial intelligence, and analytics to transform operations, By leveraging large datasets, these tools provide insights, enhance decision-making, and enable predictive modeling to drive strategic growth.',
    'link'  => '/service/ai-and-data-driven/'
  ],

  [
    'title' => 'Business Solutions',
    'text'  => 'Empower your business with data‑driven insights, automation frameworks, and custom solutions that drive smarter decisions, optimize processes, and unlock growth opportunities.',
    'link'  => '/service/business-solutions/'
  ],
];
?><section id="ourServices" class="py-5 bg" aria-labelledby="ourServicesHeading">
  <div class="container">
    <div class="row justify-content-center align-items-start gy-4">

      <!-- Text Column -->
      <div class="col-12 col-xl-7" data-aos="fade-left">
        <header class="mb-3">
          <span class="sub-heading-title d-inline-block mb-2">
            <?= htmlspecialchars($ourServicesection['subtitle']) ?>
          </span>
          <h2 id="ourServicesHeading" class="heading-title mb-3">
            <?= $ourServicesection['title'] ?>
          </h2>
        </header>
        <p class="mx-auto text-start"> 
          <?= nl2br(htmlspecialchars($ourServicesection['description'])) ?>
        </p>
      </div>

      <!-- Carousel Column -->
      <div class="col-12 col-xl-5" data-aos="fade-right">
        <div id="ourServicesCarousel"
          class="carousel slide"
          data-bs-ride="carousel"
          data-bs-interval="6000"
          data-bs-pause="hover"
          aria-labelledby="ourServicesHeading">

          <div class="carousel-inner">
            <?php
            $chunks = array_chunk($ourServices, 2); // Two services per slide
            foreach ($chunks as $chunkIndex => $chunkItems): ?>
              <div class="carousel-item <?= $chunkIndex === 0 ? 'active' : '' ?>"
                role="group"
                aria-roledescription="slide"
                aria-label="Service group <?= $chunkIndex + 1 ?> of <?= count($chunks) ?>">
                <div class="d-flex flex-column gap-4">
                  <?php foreach ($chunkItems as $index => $service): ?>
                    <a href="<?= htmlspecialchars($service['link']) ?>"
                      class="text-decoration-none"
                      aria-label="Learn more about <?= htmlspecialchars($service['title']) ?>">
                      <article class="card theme-card h-100 border-0 rounded-0 p-3 d-flex flex-column">
                        <div class="card-body d-flex flex-column h-100">
                          <h3 class="card-title h5 mb-2">
                            <?= htmlspecialchars($service['title']) ?>
                          </h3>
                          <p class="card-text mb-0  lh-base">
                            <?= htmlspecialchars($service['text']) ?>
                          </p>
                        </div>
                      </article>
                    </a>
                  <?php endforeach; ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>


    </div>
  </div>
</section>