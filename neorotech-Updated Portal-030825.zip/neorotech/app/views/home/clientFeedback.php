<?php
declare(strict_types=1);

$testimonialSection = [
  'subtitle' => 'Client Feedback',
  'title'    => '<span>Guided by</span> industry <span>experts</span> and <span>visionaries</span>',
  'image'    => '/assets/images/client/client.jpg',
];

$testimonials = [
  [
    'quote'  => 'Collaborating with Neorotech Solutions was one of the smartest decisions for our business. Their expertise and innovative approach helped us overcome challenges and achieve measurable growth',
    'name'   => 'Max Earth Resources Limited',
    'role'   => 'Team Max Earth Resources',
    'rating' => 5,
  ],
  [
    'quote'  => 'Neorotech Solutions has proven to be a reliable long-term partner. Their consistent support, innovative solutions, and commitment to excellence have been invaluable to our growth and success.',
    'name'   => 'Optimum Performance Pvt. Limited',
    'role'   => 'Team Optimum Performance',
    'rating' => 5,
  ],
  [
    'quote'  => 'Our experience with Neorotech Solutions was seamless and highly productive. Their team’s professionalism and expertise made every step smooth, and the outcomes exceeded our expectations.',
    'name'   => 'Aster Limited',
    'role'   => 'Team Aster',
    'rating' => 5,
  ],
];

$userImages = [
  '/assets/images/partner/max-logo.png',
  '/assets/images/partner/optimum-performance.png',
  '/assets/images/partner/aster.png',
];
?>
<section id="testimonial" class="testimonial-section bg py-5" aria-labelledby="testimonialHeading">
  <div class="container">
    <div class="row">

      <!-- Section Header -->
      <div class="col-12 text-center mb-4" data-aos="fade-up">
        <span class="sub-heading-title text-uppercase fw-bold d-inline-block mb-2">
          <?= htmlspecialchars($testimonialSection['subtitle']) ?>
        </span>
        <h2 id="testimonialHeading" class="heading-title my-3">
          <?= $testimonialSection['title'] ?>
        </h2>
      </div>

      <!-- Testimonial Carousel -->
      <div class="col-12 col-xl-6 order-xl-1 mb-4" data-aos="fade-right">
        <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000" data-bs-pause="hover">
          <div class="carousel-inner">
            <?php foreach ($testimonials as $index => $testimonial): ?>
              <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>" role="group" aria-label="Testimonial <?= $index + 1 ?> of <?= count($testimonials) ?>">
                <figure class="testimonial-card p-4 rounded h-100" data-aos="zoom-in" data-aos-delay="100">
                  <blockquote class="blockquote mb-3">
                    <p class="fst-italic">“<?= htmlspecialchars($testimonial['quote']) ?>”</p>
                  </blockquote>
                  <figcaption>
                    <h6 class="fw-bold mb-1"><?= htmlspecialchars($testimonial['name']) ?></h6>
                    <small class="mx-auto d-block mb-2"><?= htmlspecialchars($testimonial['role']) ?></small>
                  </figcaption>

                  <div class="testimonial-rating text-warning mb-3" aria-label="Rated <?= $testimonial['rating'] ?> out of 5 stars">
                    <?php for ($i = 0; $i < $testimonial['rating']; $i++): ?>
                      <i class="fas fa-star" aria-hidden="true"></i>
                    <?php endfor; ?>
                  </div>

                  <!-- Image Grid -->
                  <div class="testimonial-grid row row-cols-3 row-cols-sm-4 row-cols-md-5 g-3 justify-content-center align-items-center">
                    <?php foreach ($userImages as $imgIndex => $imgUrl): ?>
                      <div class="col text-center">
                        <img
                          src="<?= htmlspecialchars($imgUrl) ?>"
                          alt="Client logo <?= $imgIndex + 1 ?>"
                          loading="lazy"
                          width="72"
                          height="72"
                          class="img-fluid rounded-circle brightness-90 client-feedback-icon <?= $imgIndex === $index ? 'border border-3 border-primary' : '' ?>"
                        >
                      </div>
                    <?php endforeach; ?>
                  </div>
                </figure>
              </div>
            <?php endforeach; ?>
          </div>

          <!-- Carousel Indicators -->
          <div class="testimonial-indicators d-flex justify-content-center mt-4" role="tablist">
            <?php foreach ($testimonials as $index => $_): ?>
              <button
                type="button"
                data-bs-target="#testimonialCarousel"
                data-bs-slide-to="<?= $index ?>"
                class="btn btn-outline-primary mx-1 <?= $index === 0 ? 'active' : '' ?>"
                aria-current="<?= $index === 0 ? 'true' : 'false' ?>"
                aria-label="Go to testimonial <?= $index + 1 ?>"
              ></button>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- Accompanying Image -->
      <div class="col-12 col-xl-6 order-xl-2 d-flex justify-content-center align-items-center" data-aos="fade-left">
        <div class="testimonial-image zoom-effect">
          <img
            src="<?= htmlspecialchars($testimonialSection['image']) ?>"
            alt="Happy clients at Neorotech"
            class="img-fluid"
            loading="lazy"
          >
        </div>
      </div>

    </div>
  </div>
</section>



<!-- Accessibility Carousel Sync -->
<script>
document.addEventListener('DOMContentLoaded', function () {
  const carousel = document.getElementById('testimonialCarousel');
  const indicators = carousel.querySelectorAll('[data-bs-slide-to]');
  carousel.addEventListener('slid.bs.carousel', event => {
    indicators.forEach((btn, idx) => {
      btn.classList.toggle('active', idx === event.to);
      btn.setAttribute('aria-current', idx === event.to ? 'true' : 'false');
    });
  });
});
</script>
