<?php
declare(strict_types=1);

// About section content
$aboutText = [
  'sectionSubtitle' => 'About',
  'sectionTitle'    => 'Empowering <span>Digital Growth</span> with <span>Expertise</span> and <span>Innovation</span>',
  'description'     => <<<TEXT
At Neorotech, we seamlessly blend the agility of digital trendsetters with the wisdom of academic and industry veterans, This distinctive synergy allows us to transform emerging innovations into lasting business impact. 
Our solutions, rooted in cutting-edge technology yet timeless in essence, empower enterprises, emerging businesses, and startups alike.
As a full-spectrum software company, we drive growth through innovative product development, strategic communication, and intelligent digital experiences tailored to your goals.
TEXT,
];

// About image content
$aboutImageDetails = [
  'imagePath' => '/assets/images/about/about.jpg',
  'imageAlt'  => 'Office Team at Neorotech Solutions',
];

// Call-to-action button
$callToAction = [
  'label'     => 'Learn More',
  'link'      => '/about/index',
  'iconClass' => 'fa-solid fa-arrow-right-long ms-2',
];

// Feature highlight
$featureHighlight = [
  'iconClass' => 'fa-solid fa-shield-halved fs-1',
  'title'     => 'Tech Highlights',
  'details'   => 'Powered by advanced technologies and guided by proven architectural principles, we deliver scalable, future-ready solutions using AI, cloud, and microservices for startups to enterprises.',
];
?><section id="about" class="py-5" aria-labelledby="about-heading">
  <div class="container">
    <div class="row align-items-center g-5">

      <!-- Text Column -->
      <div class="col-lg-6" data-aos="fade-right">
        <header>
          <span class="sub-heading-title d-inline-block mb-2">
            <?= htmlspecialchars($aboutText['sectionSubtitle']) ?>
          </span>
          <h2 id="about-heading" class="heading-title my-3">
            <?= $aboutText['sectionTitle'] ?>
          </h2>
        </header>
        <p class="mx-auto text-start">
          <?= nl2br(htmlspecialchars($aboutText['description'])) ?>
        </p>
      </div>

      <!-- Image + Feature + CTA Column -->
      <div class="col-lg-6" data-aos="fade-left">
        <div class="ms-xl-5">

          <!-- Image Block -->
          <figure class="zoom-effect mb-4 brightness-90">
            <img
              src="<?= htmlspecialchars($aboutImageDetails['imagePath']) ?>"
              alt="<?= htmlspecialchars($aboutImageDetails['imageAlt']) ?>"
              class="img-fluid rounded-0 shadow-sm"
              loading="lazy"
              decoding="async"
            >
          </figure>

          <!-- Feature Highlight -->
          <div class="d-flex align-items-start mb-3">
            <div class="rounded-icon-container flex-shrink-0 me-3">
              <i class="<?= htmlspecialchars($featureHighlight['iconClass']) ?>" aria-hidden="true"></i>
            </div>
            <div>
              <h3 class="mb-1 h5"><?= htmlspecialchars($featureHighlight['title']) ?></h3>
              <p class="mx-auto text-start"><?= htmlspecialchars($featureHighlight['details']) ?></p>
            </div>
          </div>

          <!-- CTA Button -->
          <a
            href="<?= htmlspecialchars($callToAction['link']) ?>"
            class="btn theme-btn mt-3"
            aria-label="<?= strip_tags($callToAction['label']) ?>"
          >
            <?= htmlspecialchars($callToAction['label']) ?>
            <i class="<?= htmlspecialchars($callToAction['iconClass']) ?>" aria-hidden="true"></i>
          </a>

        </div>
      </div>

    </div>
  </div>
</section>


