<?php

declare(strict_types=1);

$section = [
  'backgroundImage' => '/assets/images/banner/bg-2.jpg',
  'heading'         => 'Project Accomplishments',
  'title'           => '<span>Delivering</span> Excellence in Every <span>Project</span>',
  'description'     => 'At Neorotech Solutions, we specialize in providing innovative, scalable IT solutions and services that are customized to align with the strategic objectives and evolving operational needs of businesses globally, driving efficiency and technological transformation.',
  'cta'             => ['url' => '/product/index', 'text' => 'Read More'],
  'stats' => [
    ['icon' => 'fa-solid fa-layer-group fs-2', 'count' => '04+', 'label' => 'Projects Completed'],
    ['icon' => 'fa-regular fa-face-smile fs-2', 'count' => '04+', 'label' => 'Happy Clients'],
    ['icon' => 'fa-solid fa-shield-halved fs-2', 'count' => '04+', 'label' => 'Achievements'],
    ['icon' => 'fa-solid fa-stairs fs-2', 'count' => '01+', 'label' => 'Years Experience'],
  ],
];
?><section
  id="accomplishments"
  class="py-5 accomplishments-bg"
  aria-labelledby="accomplishments-heading">
  <div class="container">
    <div class="row align-items-center gy-5">

      <!-- Text Column -->
      <div class="col-lg-6" data-aos="fade-right">
        <header>
          <span class="sub-heading-title d-inline-block mb-2">
            <?= htmlspecialchars($section['heading']) ?>
          </span>
          <h2 id="accomplishments-heading" class="heading-title my-3">
            <?= $section['title'] ?>
          </h2>
        </header>
        <p class="mx-auto text-start">
          <?= htmlspecialchars($section['description']) ?>
        </p>
        <a
          href="<?= htmlspecialchars($section['cta']['url']) ?>"
          class="btn theme-btn mt-3"
          aria-label="<?= strip_tags($section['cta']['text']) ?>">
          <?= htmlspecialchars($section['cta']['text']) ?>
        </a>
      </div>

      <!-- Stats Column -->
      <div class="col-lg-6" data-aos="fade-left">
        <div class="ms-xl-5">
          <div class="row gy-4">
            <?php foreach ($section['stats'] as $index => $stat): ?>
              <div class="col-12 col-sm-6 col-lg-4" data-aos="zoom-in" data-aos-delay="<?= 100 * ($index + 1) ?>">
                <article class="card theme-card h-100 border-0 rounded-0 p-3 d-flex flex-column text-center text-dark">
                  <div class="card-body d-flex flex-column justify-content-center h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                      <div class="icon-box flex-shrink-0">
                        <i class="<?= htmlspecialchars($stat['icon']) ?>" aria-hidden="true"></i>
                      </div>
                      <span class="stat-count fw-bold mx-auto">
                        <?= htmlspecialchars($stat['count']) ?>
                      </span>
                    </div>
                    <h3 class="card-title h5 mb-0">
                      <?= htmlspecialchars($stat['label']) ?>
                    </h3>
                  </div>
                </article>
              </div>

            <?php endforeach; ?>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>