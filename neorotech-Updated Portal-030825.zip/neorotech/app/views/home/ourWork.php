<?php

declare(strict_types=1);

$projectSection = [
  'subtitle'    => 'Empower Digital Success Through Execution',
  'title'       => 'Why <span>We Are</span> Your <span>Trusted Partner</span>',
  'description' => 'At Neorotech Solutions, we don’t just deliver technology—we engineer intelligent, scalable foundations that power transformation and accelerate growth. Our unique blend of academic depth, industry wisdom, and forward-thinking innovation positions us as a long-term strategic partner to startups, scale-ups, and enterprises worldwide.',
];

$projectsList = [
  [
    'title'       => 'Future-Ready Engineering',
    'description' => 'Guided by proven architectural principles and powered by emerging technologies like hyperautomation, IoT, AI, and microservices, we ensure every solution is built to scale and evolve.',
  ],
  [
    'title'       => 'Client-Centric Execution',
    'description' => 'We work as an extension of your team—bridging strategy, design, and engineering to translate complex challenges into high-impact, measurable outcomes.',
  ],
  [
    'title'       => 'Global Reach, Local Expertise',
    'description' => 'Serving a wide array of industries and regions, our approach is rooted in international best practices, adapted with localized insights to meet unique market demands.',
  ],
  [
    'title'       => 'Reliable, Secure, and Scalable',
    'description' => 'We prioritize performance, security, and sustainability—delivering solutions that are not only resilient today, but ready for tomorrow.',
  ],
  [
    'title'       => ' Culture of Innovation & Learning',
    'description' => 'Our people are our core strength. We continuously invest in upskilling, research, and experimentation—ensuring your business always benefits from the latest tools, knowledge, and breakthroughs.',
  ],
  [
    'title'       => 'Delivering Trusted Solutions',
    'description' => 'Our people are our core strength. We continuously invest in upskilling, research, and experimentation—ensuring your business always benefits from the latest tools, knowledge, and breakthroughs.',
  ],
];
?>
<section id="projects" class="py-5 bg-primary" aria-labelledby="projects-heading">
  <div class="container">

    <!-- Section Header -->
    <div class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <span class="sub-heading-title d-inline-block mb-2">
          <?= htmlspecialchars($projectSection['subtitle']) ?>
        </span>
        <h2 id="projects-heading" class="heading-title my-3">
          <?= $projectSection['title'] ?>
        </h2>
        <p class="mx-auto text-start">
          <?= nl2br(htmlspecialchars($projectSection['description'])) ?>
        </p>
      </div>
    </div>

    <!-- Project Cards Grid -->
    <div class="row g-4">
      <?php foreach ($projectsList as $index => $project): ?>
        <div class="col-12 col-sm-6 col-lg-4 d-flex" data-aos="zoom-in" data-aos-delay="<?= 100 * ($index + 1) ?>">
          <article class="card theme-card h-100 border-0 rounded-0 p-3 d-flex flex-column text-dark">
            <div class="card-body d-flex flex-column h-100">
              <h3 class="card-title h5 mb-2">
                <?= htmlspecialchars($project['title']) ?>
              </h3>
              <p class="card-text mb-0  lh-base">
                <?= htmlspecialchars($project['description']) ?>
              </p>
            </div>
          </article>
        </div>

      <?php endforeach; ?>
    </div>

  </div>
</section>