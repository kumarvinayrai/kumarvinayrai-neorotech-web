<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-13.jpg';
$bannerHeading = 'AI and Data-Driven Solutions';
$bannerText    = 'AI and data-driven solutions enable insights, automation, and smarter decision-making for businesses';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Content
$servicesData = [
  'sectionId'  => 'ai-and-data-driven',
  'title'      => 'Unlock <span>Insights</span> and <span>Innovation<span/> with <span>AI-Powered</span> Data Solutions',
  'introParas' => [
    'AI and Data-Driven Solutions combine machine learning, artificial intelligence, and analytics to transform operations, By leveraging large datasets, these tools provide insights, enhance decision-making, and enable predictive modeling to drive strategic growth.',
    'AI algorithms automate tasks, optimize processes, and uncover patterns often overlooked by humans. Whether through personalization, risk prediction, or process efficiency, data-driven systems empower businesses to make informed decisions.'
  ]
];
?>
<!-- AI and Data-Driven Solutions Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Section Title -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Intro Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>  
        </div> 
  </div>
</section>


<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
