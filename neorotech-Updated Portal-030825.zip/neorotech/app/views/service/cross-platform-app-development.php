<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-26.jpg';
$bannerHeading = 'Cross-Platform App Development';
$bannerText    = 'Deliver Consistent User Experiences with Cross-Platform App Development for Both iOS and Android Devices';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'cross-platform-app-development',
    'title'        => 'Custom <span>Cross-Platform Development</span> for <span>Your Business</span>',
    'introParas'   => [
        'Cross-platform app development is a cost-effective solution that enables apps to run on multiple platforms (iOS, Android, etc.) from a single codebase.',
        'Using frameworks like React Native, Flutter, and Xamarin, our team can create apps that deliver a native-like experience while reducing development time and cost. Cross-platform apps are ideal for businesses aiming to reach a wider audience quickly, as they offer consistent functionality and design across devices, with only minor adjustments needed for each platform.',
    ]
];
?>
<!-- Cross-Platform App Development Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">
      
      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
