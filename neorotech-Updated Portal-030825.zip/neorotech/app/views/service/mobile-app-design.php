<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-21.jpg';
$bannerHeading = 'Mobile App Design';
$bannerText    = 'Designing intuitive, visually engaging mobile apps that provide seamless user experiences for improved engagement and retention';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'mobile-app-design',
    'title'        => 'Cutting-Edge <span>Mobile App</span> Design <span>Tailored</span> for Every Platform',
    'introParas'   => [
        'We specialize in mobile app design, focusing on creating user-friendly, visually appealing interfaces that ensure seamless navigation and engagement, Our designs are optimized for performance across various mobile devices, making your app intuitive and enjoyable to use and We enhance user retention by delivering functional, aesthetically pleasing mobile experiences tailored to your audience and business goals.'
    ]
];
?>
<!-- Mobile App Design Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">
      
      <!-- Heading -->
     <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
