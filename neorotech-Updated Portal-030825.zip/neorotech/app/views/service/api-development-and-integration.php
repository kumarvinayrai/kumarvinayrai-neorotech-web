<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-32.jpg';
$bannerHeading = 'API Development and Integration';
$bannerText    = 'Building scalable APIs for streamlined integration, automation, and improved data connectivity';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Section Data
$servicesData = [
    'sectionId'    => 'api-development-integration',
    'title'        => 'Seamless <span>API Development</span> and <span>Integration</span> for <span>Business</span> Efficiency',
    'introParas'   => [
        'APIs (Application Programming Interfaces) are the backbone of modern software integration. Our API development and integration services empower applications to communicate and share data seamlessly, creating a unified ecosystem that improves operational workflows and productivity.',
        'We design and implement secure, scalable APIs for both new and legacy systems, enabling real-time data exchange across platforms such as CRMs, ERPs, payment gateways, social media, and more.',
        'Our team follows industry best practices and modern security standards to ensure that all API transactions are protected, reliable, and aligned with your business objectives.'
    ]
];
?>
<!-- API Development and Integration Section -->
<section
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>"
  class="position-relative py-5"
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Section Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Section Paragraphs -->
       <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
