<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-30.jpg';
$bannerHeading = 'Custom Web Application Development';
$bannerText    = 'Crafting High-Performance Web Apps with Customized Features for Unique Business Needs';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'custom-web-application-development',
    'title'        => 'Building <span>Scalable Web Applications</span> for <span>Business Growth</span>',
    'introParas'   => [
        'We specialize in building custom web applications that are uniquely crafted to meet your specific business objectives and challenges and uur team focuses on understanding your business processes and user expectations to create web solutions that drive efficiency, productivity, and user engagement.',
        ' Whether it’s an e-commerce platform, customer portal, or a specialized industry-specific tool, we prioritize scalability, security, and seamless user experience to help you achieve a competitive edge. Our development process is collaborative, with regular feedback loops to ensure the final product aligns with your vision and goals.',
    ]
];
?>
<!-- Custom Web Application Development Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Intro Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
