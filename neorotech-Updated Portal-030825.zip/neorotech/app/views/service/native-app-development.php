<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-02.jpg';
$bannerHeading = 'Native App Development';
$bannerText    = 'Transform Your Ideas into Reality with Native App Development: Fast, Secure, and Scalable Mobile Solutions';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'native-app-development',
    'title'        => 'Innovative <span>Native App Development</span> for <span>Every Platform</span>',
    'introParas'   => [
        'Native app development involves creating applications specifically designed for a particular operating system, such as iOS or Android. By building apps using platform-specific languages (Swift or Objective-C for iOS, Java or Kotlin for Android), native apps take full advantage of device capabilities, ensuring high performance, fast load times, and a smooth user experience.',
        'These apps can leverage device hardware and software features, like cameras, GPS, and sensors, providing a seamless, responsive, and reliable experience for users.',
    ]
];
?>
<!-- Native App Development Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5"
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
