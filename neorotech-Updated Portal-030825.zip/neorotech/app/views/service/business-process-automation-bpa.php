<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-07.jpg';
$bannerHeading = 'Business Process Automation (BPA)';
$bannerText    = 'Automate repetitive tasks to improve efficiency, reduce human error, and save time with BPA solutions';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Section Content
$servicesData = [
    'sectionId'    => 'business-process-automation-bpa',
    'title'        => 'Optimize <span>Business Performance</span> with <span>Process Automation</span>',
    'introParas'   => [
        'Business Process Automation (BPA) streamlines and automates repetitive tasks to improve operational efficiency and reduce human error. We help businesses digitize workflows in key areas like HR, finance, and supply chain, allowing employees to focus on higher-value tasks. BPA solutions boost productivity, reduce costs, and eliminate inefficiencies.',
        'Whether it’s automating approvals, document handling, or customer service, our BPA solutions help you optimize processes, enable agile workflows, and drive growth by minimizing manual intervention and operational overhead.'
    ]
];
?>

<!-- BPA Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Paragraphs --> 
       <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>


<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
