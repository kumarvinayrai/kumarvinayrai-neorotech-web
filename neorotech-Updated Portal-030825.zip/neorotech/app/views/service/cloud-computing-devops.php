<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-19.jpg';
$bannerHeading = 'Cloud Computing & DevOps Services';
$bannerText    = 'Empower your business with cloud and DevOps solutions that optimize infrastructure, automate workflows, and ensure security';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'cloud-computing-devops',
    'title'        => 'Empower <span>Your Business</span> with Scalable <span>Cloud Computing</span> and <span>DevOps</span> Solutions',
    'introParas'   => [
        'At Neorotech Solutions Technologies, we offer cloud computing and DevOps services that optimize infrastructure, enhance deployment speed, and improve security, Our solutions help streamline your workflows, from cloud setup and management to continuous integration and deployment.',
        ' We ensure your cloud environment is scalable, reliable, and secure, with automated processes that support innovation and growth, Let us help you transition to the cloud and implement DevOps best practices to accelerate your software development and deployment cycles.'
    ]
];
?>
<!-- Cloud Computing & DevOps Services Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Section Heading -->
     <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Introductory Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
