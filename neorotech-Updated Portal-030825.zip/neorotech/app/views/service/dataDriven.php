<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-37.jpg';
$bannerHeading = 'Data-Driven Solutions';
$bannerText    = 'Data-driven solutions enable insights, automation, and smarter decision-making for businesses';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// About section content
$aboutText = [
  'sectionTitle' => 'Data Driven Solutions',
  'description'  => <<<HTML
    <article>
      <p class="lh-base">
        At <strong>Neorotech Solution</strong>, our philosophy is simple: to harness the power of technology to drive positive change and create value for our clients and society. We believe in the transformative potential of data-driven insights, innovation, and collaboration to solve complex challenges and achieve sustainable growth.
      </p>
      <p class="lh-base">
        Our approach is rooted in transparency, integrity, and a commitment to excellence. We believe in listening to our clients, understanding their needs, and delivering tailored solutions that exceed expectations. With a focus on continuous improvement and agility, we adapt to changing market dynamics and embrace new technologies to stay ahead of the curve.
      </p>
    </article>
HTML,
];
?>

<section id="dataDriven" class="position-relative py-5" aria-labelledby="about-heading">
  <div class="container">

    <!-- Section Header -->
    <div class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <h2 id="about-heading" class="heading-title my-3">
          <?= $aboutText['sectionTitle'] ?>
        </h2>
        <div class="mx-auto text-start">
          <?= $aboutText['description'] ?>
        </div> 
      </div>
    </div>

  </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
