<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-33.jpg';
$bannerHeading = 'Third-Party Integrations';
$bannerText    = 'Boost Business Performance through Reliable and Secure Third-Party Integrations and Automation';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    // Use a valid HTML ID — lowercase, hyphen-separated, no spaces
    'sectionId'    => 'third-party-integrations', 
    'title'        => 'Enhance <span>Business Systems</span> with <span>Third-Party Integrations</span>',
    'introParas'   => [
        // Fixed typo: "Extend" (was "xtend")
        'Extend your website’s functionality and enhance user experience through third-party integrations, Our team can integrate a wide range of third-party tools and services, including payment gateways, CRM systems, email marketing software, social media channels, and analytics platforms, These integrations allow your website to offer more robust features and services without requiring extensive in-house development.',
        'Whether you’re looking to add a booking system, automate customer communication, or incorporate advanced analytics, we handle the technicalities so you can focus on what matters most—growing your business.',
    ]
];
?>
<!-- Third-Party Integrations Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Title Section -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2 
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" 
            class="heading-title mb-3"
          >
            <?= $servicesData['title'] ?>
          </h2>
        </header>

      <!-- Description Section --> 
       <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
