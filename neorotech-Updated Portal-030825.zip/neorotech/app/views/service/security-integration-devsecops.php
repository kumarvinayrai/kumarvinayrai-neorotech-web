<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-16.jpg';
$bannerHeading = 'Security Integration (DevSecOps)';
$bannerText    = 'Integrate security at every stage of development to ensure compliance, protection, and secure deployment';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'security-integration-devsecops',
    'title'        => '<span>Comprehensive Security Integration</span> with <span>DevSecOps</span>',
    'introParas'   => [
        'DevSecOps integrates security into every phase of the development lifecycle, ensuring your applications are protected from the ground up, We help embed security best practices early in the process, automate vulnerability checks, and maintain regulatory compliance throughout.',
        'By incorporating continuous security into your CI/CD pipelines, we help minimize risks, enforce consistent protections, and ensure data privacy at every stage. Our DevSecOps approach offers peace of mind—delivering secure, compliant, and resilient software.',
    ]
];
?>
<!-- Security Integration (DevSecOps) Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">
      
      <!-- Title Section -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2 
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" 
            class="heading-title my-3"
          >
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Description Section -->
    <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
