<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-11.jpg';
$bannerHeading = 'Natural Language Processing (NLP)';
$bannerText    = 'Transform unstructured data into actionable insights using advanced Natural Language Processing (NLP) technology';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'natural-language-processing-nlp',
    'title'        => 'Enhance <span>User Interactions</span> Using <span>Natural Language Processing</span> Solutions',
    'introParas'   => [
        'Our NLP solutions leverage advanced algorithms to enable machines to understand, interpret, and generate human language From chatbots that can comprehend customer queries to sentiment analysis tools that gauge customer satisfaction, we design NLP systems that enhance communication and decision-making.',
        'Our NLP services can be applied to customer service automation, document analysis, voice recognition, and more, helping you improve customer engagement and streamline workflows.',
    ]
];
?><!-- NLP Service Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5"
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">

    <!-- Section Heading -->
    <div class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header>
        <!-- Paragraphs --> 
         <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>
    </div> 

  </div>
</section>


<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
