<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-41.jpg';
$bannerHeading = 'UI/UX Audits & Enhancements';
$bannerText    = 'UI/UX audits identify usability issues, improving design for better user engagement, experience, and conversions';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'ui-ux-audits-enhancements', 
    'title'        => 'Strategic <span>UI/UX Audits</span> and <span>Enhancements</span> for <span>Every Platform</span>',
    'introParas'   => [
        'Our UI/UX audits evaluate your existing designs to identify usability and engagement issues,We offer actionable insights to enhance your digital interfaces, optimizing user experience and improving conversion rates and our Regular audits and enhancements ensure that your product stays competitive, meets evolving user needs, and delivers a superior experience.'
    ]
];
?><!-- UI/UX Audits & Enhancements Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">
      
      <!-- Title -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2 
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" 
            class="heading-title mb-3"
          >
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Description -->
       <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
