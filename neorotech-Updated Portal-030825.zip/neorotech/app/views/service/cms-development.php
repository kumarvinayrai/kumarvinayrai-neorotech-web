<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-31.jpg';
$bannerHeading = 'CMS App Development';
$bannerText    = 'Tailored CMS Solutions for Easy Content Management, Scalability, and Enhanced User Experience';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
  'sectionId'    => 'cms-development',
  'subheading'   => 'CMS Development',
  'title'        => 'Build Custom <span>CMS Platforms</span> for <span>Efficient Content Control</span>',
  'introParas'   => [
    'Our CMS development services enable you to manage and update website content effortlessly, without requiring technical expertise. We work with popular Content Management Systems such as WordPress, Drupal, and Joomla, and also build custom CMS solutions tailored to your needs.',
    'With an intuitive, user-friendly interface, our CMS solutions empower your team to take control of your website’s content, images, and multimedia, From managing blog posts and product catalogs to updating pages and uploading resources, a CMS is ideal for businesses looking for flexibility and ease of use.'
  ]
];
?>
<!-- CMS App Development Section -->
<section
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>"
  class="position-relative py-5"
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
  <div class="container">
    <div class="row">

      <!-- Section Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 
      <!-- Section Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p
            class="mx-auto text-start"
            <?= $index === 0 ? 'data-aos="fade-left" data-aos-delay="100"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>