<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-43.jpg';
$bannerHeading = 'Website Maintenance and Support';
$bannerText    = 'Expert Website Maintenance and Support to Improve Performance, Security, and Functionality';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'website-maintenance',
    'subheading'   => 'Our Services',
    'title'        => 'End-to-End <span>IT Services</span> for <span>Web Development</span>',
    'introParas'   => [
        'Websites require regular updates and monitoring to remain secure, functional, and aligned with the latest technologies. Our website maintenance and support services are designed to keep your website running smoothly and securely, ensuring minimal downtime and maximum performance.',
        'We provide ongoing support that includes software updates, security patches, performance optimizations, and content updates. Additionally, we offer data backups and monitoring services to safeguard your website from potential threats and provide peace of mind and Our proactive approach helps prevent issues before they arise, so you can focus on your core business.'
    ]
];
?>
<!-- Website Maintenance Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Title Column -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header> 
          <h2 
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" 
            class="heading-title my-3"
          >
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Description Column -->
      <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start"><?= htmlspecialchars($para) ?></p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>


<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
