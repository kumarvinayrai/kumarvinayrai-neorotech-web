<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-40.jpg';
$bannerHeading = 'Product Design and Development';
$bannerText    = 'We design user-centered products, balancing aesthetics with functionality to create impactful, innovative solutions for users';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'product-design',
    'title'        => 'Innovative <span>Product Design</span> for Every Platform',
    'introParas'   => [
        'Product design at Neorotech Solutions Technologies focuses on creating innovative, user-centered solutions that blend functionality with aesthetics. Our design process ensures that each product addresses real user needs while aligning with your brand identity.',
        'By emphasizing usability and intuitive design, we create products that drive user satisfaction, boost engagement, and ensure long-term success in the market.',
    ]
];
?>
<!-- Product Design and Development Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3"
          >
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Paragraphs --> 
       <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>
      
    </div>
  </div>
</section>


<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
