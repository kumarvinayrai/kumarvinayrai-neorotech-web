<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-38.jpg';
$bannerHeading = 'Continuous Integration & Continuous Deployment';
$bannerText    = 'Automate software deployment with CI/CD to accelerate release cycles, improve quality, and ensure reliability';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'continuous-integration-continuous-deployment-ci-cd',
    'title'        => 'Seamless <span>Continuous Integration</span> and <span>Deployment (CI/CD)</span> Across Every Platform',
    'introParas'   => [
        'CI/CD practices automate the software development lifecycle, enabling quicker and more reliable releases. We help you implement continuous integration and continuous deployment pipelines that integrate code changes automatically, test them for quality, and deploy seamlessly.',
        ' This reduces manual errors, accelerates development, and ensures high-quality releases With our CI/CD services, you can rapidly deliver new features and improvements, allowing your business to stay agile, competitive, and responsive to customer needs.'
    ]
];
?>
<!-- CI/CD Services Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Intro Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
