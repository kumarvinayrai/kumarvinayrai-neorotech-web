<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-25.jpg';
$bannerHeading = 'Mobile App Development Services';
$bannerText    = 'End-to-End Mobile App Development Services: From Concept to Deployment, We Build Seamless User Experiences';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'mobile-app-development-services', 
    'title'        => 'Building <span>Scalable</span>, <span>High-Performance</span> Mobile Apps',
    'introParas'   => [
        'Our mobile app development services encompass native and cross-platform applications, ensuring high performance across all devices, We create custom mobile apps tailored to your business needs, hybrid solutions that blend web and native capabilities, and immersive AR/VR applications to enhance user engagement and provide innovative mobile experiences.',
    ]
];
?>
<!-- Mobile App Development Services Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">
      
      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Intro Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
