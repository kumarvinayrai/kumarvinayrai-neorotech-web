<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-29.jpg';
$bannerHeading = 'Augmented Reality & Virtual Reality Apps';
$bannerText    = 'Transform ideas into reality with innovative AR and VR app solutions for businesses and users';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Section Content
$servicesData = [
    'sectionId'    => 'augmented-reality-virtual-reality-apps',
    'title'        => '<span>Empower</span> Your Brand with <span>AR/VR</span> Technology',
    'introParas'   => [
        'Augmented Reality (AR) and Virtual Reality (VR) technologies deliver immersive and interactive experiences that engage users like never before,Our AR/VR app development services help businesses build captivating applications for industries such as retail, real estate, education, and entertainment.',
        'Leveraging advanced technologies, we create apps that either enhance real-world environments (AR) or provide fully immersive digital experiences (VR). These apps are ideal for virtual tours, training simulations, product demos, and customer engagement — delivering real value through innovation and interaction.'
    ]
];
?>
<!-- AR/VR Apps Section -->
<section
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>"
  class="position-relative py-5"
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header>
       <!-- Paragraphs --> 
         <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
