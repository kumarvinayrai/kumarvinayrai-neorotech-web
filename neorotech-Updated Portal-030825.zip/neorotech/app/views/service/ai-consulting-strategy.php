<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-10.jpg';
$bannerHeading = 'AI Consulting & Strategy';
$bannerText    = 'AI Consulting & Strategy Solutions guide businesses in leveraging AI for growth, innovation, and efficiency';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Section Data
$servicesData = [
  'sectionId'  => 'ai-consulting-strategy',
  'title'      => 'Transformative <span>AI strategies</span> for <span>business innovation</span> and efficiency',
  'introParas' => [
    'Our AI consulting and strategy services help businesses unlock the potential of artificial intelligence to gain a competitive edge, We assess your current capabilities, identify high-impact opportunities for AI adoption, and develop tailored strategies aligned with your goals, Whether it’s automating routine tasks, enhancing customer interactions, or improving data analysis, our team provides guidance on the best AI tools and techniques, We also assist in implementation, team training, and seamless integration into existing workflows.'
  ]
];
?>
<!-- AI Consulting & Strategy Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Section Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Intro Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
