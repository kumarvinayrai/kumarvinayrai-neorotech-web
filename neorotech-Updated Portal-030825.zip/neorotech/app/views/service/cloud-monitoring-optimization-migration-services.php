<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-15.jpg';
$bannerHeading = 'Cloud Monitoring, Optimization & Migration Services';
$bannerText    = 'Optimize cloud performance, monitor resources, and manage migration to ensure efficient, cost-effective cloud operations';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'cloud-monitoring-optimization-migration-services',
    'title'        => 'Efficient <span>Cloud Monitoring</span>, <span>Optimization</span>, and <span>Migration</span> Across Every Platform

',
    'introParas'   => [
        'Our cloud monitoring, optimization, and migration services ensure your cloud resources perform at their best, We monitor your cloud environment in real time, identify areas for improvement, and optimize resource allocation to reduce costs.',
        'Whether you are migrating to the cloud or enhancing existing infrastructure, we make the process seamless and efficient, Our team ensures optimal performance, security, and scalability throughout the entire lifecycle of your cloud operations, driving long-term business success.'
    ]
];
?>
<!-- Cloud Monitoring, Optimization & Migration Services Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
