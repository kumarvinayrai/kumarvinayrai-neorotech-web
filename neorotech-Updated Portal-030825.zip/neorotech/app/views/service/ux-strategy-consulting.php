<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-42.jpg';
$bannerHeading = 'UI/UX Audits & Enhancements';
$bannerText    = 'UI/UX audits identify usability issues, improving design for better user engagement, experience, and conversions';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'website-maintenance', 
    'title'        => 'End-to-End <span>IT Services</span> for <span>Web Development</span>',
    'introParas'   => [
        'Websites require regular updates and monitoring to remain secure, functional, and aligned with the latest technologies. Our website maintenance and support services are designed to keep your website running smoothly and securely, ensuring minimal downtime and maximum performance.',
        'We provide ongoing support that includes software updates, security patches, performance optimizations, and content updates. Additionally, we offer data backups and monitoring services to safeguard your website from potential threats and provide peace of mind and Our proactive approach helps prevent issues before they arise, so you can focus on your core business.'
    ]
];
?>
<!-- Website Maintenance Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Title Column -->
       <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2 
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" 
            class="heading-title mb-3"
          >
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Intro Paragraphs Column --> 
        <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start"><?= htmlspecialchars($para) ?></p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>


<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
