<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-09.jpg';
$bannerHeading = 'Business Solutions';
$bannerText    = 'Optimize operations, enhance efficiency, and drive growth with our comprehensive and tailored business solutions';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Section Content
$servicesData = [
    'sectionId'    => 'business-solutions',
    'title'        => 'Transforming <span>businesses</span> with <span>innovative</span>, <span>tailored</span> solutions',
    'introParas'   => [
        'We provide tailored business solutions to streamline operations, improve efficiency, and foster sustainable growth, From implementing ERP systems that integrate your core business functions to deploying CRM tools for enhanced customer relationship management — we cover all your business needs.',
        'Our expertise includes building single-page applications (SPAs), automating processes, developing seamless e-commerce platforms, and implementing intelligent document management systems, We help businesses perform at their best and scale effectively in today’s competitive digital landscape.',
    ]
];
?>
<!-- Business Solutions Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Paragraphs -->
      <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
