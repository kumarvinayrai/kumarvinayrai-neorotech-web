<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-44.jpg';
$bannerHeading = 'UI / UX Design';
$bannerText    = 'We create intuitive UI/UX designs, blending aesthetics and functionality to enhance user satisfaction and engagement';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'ui-ux-design',  
    'title'        => 'Enhance <span>User Experience</span> with Expert <span>UI/UX Design</span> Services',
    'introParas'   => [
        'Our UI/UX design services focus on crafting seamless, engaging user experiences. We combine aesthetic appeal with functionality, ensuring that every digital interaction is intuitive, efficient, and user-centered, Whether for web or mobile, our designs help boost user satisfaction, enhance brand loyalty, and improve business outcomes.',
    ]
];
?>
<!-- UI/UX Design Services Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">
      
      <!-- Title Column -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2 
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" 
            class="heading-title mb-3"
          >
            <?= $servicesData['title'] ?>
          </h2>
        </header> 
      
      <!-- Intro Paragraphs Column -->
        <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>


<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
