<?php
declare(strict_types=1);
$servicesSectionId = 'our-services';
$techCards = [
  ['link' => '/service/dataDriven/', 'title' => 'Data-Driven Innovation', 'desc' => 'We extract powerful insights from data to create smarter, scalable strategies that unlock growth potential.', 'delay' => 100],
  ['link' => '/service/web-development/', 'title' => 'Web Development', 'desc' => 'Build high-performing, secure, and scalable websites tailored to your business goals and audience.', 'delay' => 100],
  ['link' => '/service/website-maintenance-and-support/', 'title' => 'Website Maintenance and Support', 'desc' => 'Keep your website running smoothly with our proactive maintenance, updates, and technical support services.', 'delay' => 200],
  ['link' => '/service/responsive-website-design/', 'title' => 'Responsive Website Design', 'desc' => 'Create seamless experiences across all devices with responsive designs that adapt to any screen size.', 'delay' => 300],
  ['link' => '/service/third-party-integrations/', 'title' => 'Third-Party Integrations', 'desc' => 'Enhance functionality by integrating payment gateways, CRMs, social platforms, and analytics tools.', 'delay' => 100],
  ['link' => '/service/api-development-and-integration/', 'title' => 'API Development and Integration', 'desc' => 'Connect applications and streamline operations with custom API development and integration services.', 'delay' => 200],
  ['link' => '/service/cms-development/', 'title' => 'CMS Development', 'desc' => 'Manage content easily with custom CMS solutions or popular platforms like WordPress and Drupal.', 'delay' => 300],
  ['link' => '/service/custom-web-application-development/', 'title' => 'Custom Web App Development', 'desc' => 'Develop tailored web applications to solve unique business challenges and improve efficiency.', 'delay' => 100],
  ['link' => '/service/mobile-app-development/', 'title' => 'Mobile App Development', 'desc' => 'Deliver user-friendly mobile apps that blend performance, scalability, and sleek design.', 'delay' => 200],
  ['link' => '/service/hybrid-mobile-app-development/', 'title' => 'Hybrid App Development', 'desc' => 'Build hybrid apps that work across platforms while saving development time and cost.', 'delay' => 100],
  ['link' => '/service/custom-mobile-app-development/', 'title' => 'Custom Mobile Apps', 'desc' => 'We develop bespoke mobile applications tailored to your business needs and user expectations.', 'delay' => 200],
  ['link' => '/service/cross-platform-app-development/', 'title' => 'Cross-Platform Apps', 'desc' => 'Maximize reach with apps built to perform seamlessly across iOS, Android, and the web.', 'delay' => 300],
  ['link' => '/service/native-app-development/', 'title' => 'Native App Development', 'desc' => 'Leverage platform-specific capabilities with high-performance native Android and iOS apps.', 'delay' => 100],
  ['link' => '/service/ui-ux-design/', 'title' => 'UI / UX Design', 'desc' => 'Design intuitive and visually engaging user interfaces that deliver meaningful user experiences.', 'delay' => 200],
  ['link' => '/service/ux-strategy-consulting/', 'title' => 'UX Strategy', 'desc' => 'Align your business goals with user needs to create frictionless and user-centered digital journeys.', 'delay' => 300],
  ['link' => '/service/ui-ux-audits-enhancements/', 'title' => 'UI/UX Audits', 'desc' => 'Identify usability gaps and enhance your product’s user interface with expert UI/UX evaluations.', 'delay' => 100],
  ['link' => '/service/wireframing-prototyping/', 'title' => 'Wireframing', 'desc' => 'Plan your application’s structure and layout with interactive wireframes for better clarity and feedback.', 'delay' => 200],
  ['link' => '/service/website-design/', 'title' => 'Website Design', 'desc' => 'Combine aesthetics and function with modern website designs tailored to your brand and users.', 'delay' => 300],
  ['link' => '/service/product-design/', 'title' => 'Product Design', 'desc' => 'Turn concepts into digital products with a balance of usability, form, and innovation.', 'delay' => 200],
  ['link' => '/service/microservices-api-management/', 'title' => 'Microservices', 'desc' => 'Architect your systems with microservices for agility, scalability, and faster deployments.', 'delay' => 200],
  ['link' => '/service/devops-strategy-assessment/', 'title' => 'DevSecOps', 'desc' => 'Embed security into every stage of development with our DevSecOps practices.', 'delay' => 300],
  ['link' => '/service/continuous-integration-continuous-deployment-ci-cd/', 'title' => 'CI/CD Pipelines', 'desc' => 'Automate testing and deployment with continuous integration and delivery pipelines.', 'delay' => 100],
  ['link' => '/service/cloud-monitoring-optimization-migration-services/', 'title' => 'Cloud Monitoring', 'desc' => 'Maintain peak performance and reliability through proactive cloud monitoring solutions.', 'delay' => 200],
  ['link' => '/service/ai-in-iot-internet-of-things/', 'title' => 'AI in IoT (Internet of Things)', 'desc' => 'Enable smart decision-making and automation by integrating AI with IoT devices and systems.', 'delay' => 100],
  ['link' => '/service/natural-language-processing-nlp/', 'title' => 'Natural Language Processing (NLP)', 'desc' => 'Use NLP to process and understand human language for smarter analytics and automation.', 'delay' => 300],
  ['link' => '/service/ai-consulting-strategy/', 'title' => 'AI Consulting & Strategy', 'desc' => 'Plan and implement AI-driven solutions aligned with your goals and technical infrastructure.', 'delay' => 100],
  ['link' => '/service/business-solutions/', 'title' => 'Business Solutions', 'desc' => 'Transform operations with custom digital solutions that improve productivity and scale.', 'delay' => 200],
  ['link' => '/service/document-management-systems/', 'title' => 'Document Management System', 'desc' => 'Digitize, manage, and access business documents securely from a centralized platform.', 'delay' => 300],
  ['link' => '/service/e-commerce-solutions/', 'title' => 'E-Commerce', 'desc' => 'Launch scalable e-commerce platforms with secure transactions and seamless user experiences.', 'delay' => 100],
  ['link' => '/service/business-process-automation-bpa/', 'title' => 'Business Process Automation (BPA)', 'desc' => 'Automate repetitive processes to increase efficiency and reduce operational costs.', 'delay' => 200],
  ['link' => '/service/single-page-applications/', 'title' => 'Single Page Apps', 'desc' => 'Deliver fast, interactive web experiences with SPAs that load content dynamically.', 'delay' => 300],
];
?><!-- Web Development Services Section -->
<section
  id="<?= htmlspecialchars($servicesSectionId) ?>"
  class="position-relative py-5 bg"
  aria-labelledby="<?= htmlspecialchars($servicesSectionId) ?>-heading">
  <div class="container">

    <!-- Section Heading -->
    <div class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <span class="sub-heading-title mb-2 d-inline-block">Our Services</span>
        <h2
          id="<?= htmlspecialchars($servicesSectionId) ?>-heading"
          class="heading-title mb-3">
          End-to-End <span>IT Services</span> for <span>Web Development</span> Services
        </h2>
        <p class="mx-auto text-start">
          We offer a comprehensive range of IT services designed to help businesses streamline operations, improve efficiency, and drive innovation. Whether you're a small startup or a large enterprise, our solutions are tailored to meet your unique needs and challenges.
        </p>
      </div>
    </div>

    <!-- Cards Grid -->
    <div class="row g-4">
      <?php foreach ($techCards as $card): ?>
        <div
          class="col-12 col-sm-6 col-lg-4 d-flex"
          data-aos="zoom-in"
          data-aos-delay="<?= (int)$card['delay'] ?>">
          <a
            href="<?= htmlspecialchars($card['link']) ?>"
            class="text-decoration-none w-100"
            aria-label="<?= htmlspecialchars($card['title']) ?>">
            <article class="card theme-card h-100 border-0 rounded-0 p-3 d-flex flex-column">
              <div class="card-body d-flex flex-column">
                <h3 class="card-title h5 mb-2">
                  <?= htmlspecialchars($card['title']) ?>
                </h3>
                <p class="card-text class=" row justify-content-center" mb-0">
                  <?= htmlspecialchars($card['desc']) ?>
                </p>
              </div>
            </article>
          </a>
        </div>

      <?php endforeach; ?>
    </div>

  </div>
</section>