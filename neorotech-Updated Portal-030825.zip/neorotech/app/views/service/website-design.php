<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-22.jpg';
$bannerHeading = 'Website Design';
$bannerText    = 'We create modern, visually appealing websites that deliver seamless navigation, user retention, and conversion optimization';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'website-design',
    'title'        => 'Creative <span>Web Design</span> Solutions for <span>Every Platform</span>',
    'introParas'   => [
        'Our website design services focus on creating visually engaging, user-friendly websites that stand out and we prioritize intuitive navigation, responsive design, and fast load times to enhance user experience With a focus on both aesthetics and functionality, we help attract visitors, retain users, and drive conversions, ensuring lasting online success.'
    ]
];
?>
<!-- Website Design Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Title Column -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2 
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" 
            class="heading-title my-3"
          >
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Description Column --> 
        <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start"><?= htmlspecialchars($para) ?></p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
