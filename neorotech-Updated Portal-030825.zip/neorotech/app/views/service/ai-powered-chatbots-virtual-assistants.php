<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-36.jpg';
$bannerHeading = 'AI-Powered Chatbots & Virtual Assistants';
$bannerText    = 'Develop AI chatbots and virtual assistants to automate customer service and provide efficient, round-the-clock support';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Section Content
$servicesData = [
  'sectionId'  => 'ai-powered-chatbots-virtual-assistants',
  'title'      => 'Enhance <span>user interactions</span> using <span>Natural Language</span> Processing solutions',
  'introParas' => [
    'We develop AI-powered chatbots and virtual assistants that deliver 24/7 customer support and automate routine interactions. Powered by machine learning and Natural Language Processing (NLP), our chatbots understand user intent and respond with context-aware, human-like conversations.',
    'These intelligent assistants can handle inquiries, offer personalized recommendations, and escalate complex queries to human agents when required. This reduces the workload on customer support teams while improving customer satisfaction through immediate and accurate responses.'
  ]
];
?>
<!-- Chatbots & Virtual Assistants Section -->
<section
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>"
  class="position-relative py-5"
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Section Title -->
     <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Section Paragraphs -->
        <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
