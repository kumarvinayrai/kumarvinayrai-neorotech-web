<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-12.jpg';
$bannerHeading = 'AI in IoT (Internet of Things)';
$bannerText    = 'Integrate AI with IoT for intelligent automation, real-time data processing, and insights to optimize operations';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Section Content
$servicesData = [
  'sectionId'  => 'ai-in-iot-internet-of-things',
  'title'      => '<span>AI-driven IoT</span> solutions for <span">real-time data</span> processing',
  'introParas' => [
    'Combining AI with IoT enables smarter, data-driven decision-making through real-time insights and intelligent automation, By integrating AI with connected devices, we facilitate predictive analytics, rapid data interpretation, and autonomous operations across IoT environments.',
    'These solutions are widely applied in smart manufacturing, predictive maintenance, and smart cities—helping optimize processes, reduce downtime, and boost operational efficiency, Our AI in IoT offerings bring a new level of intelligence to your operations by enabling you to monitor, analyze, and act on data from connected devices effectively.'
  ]
];
?>
<!-- AI in IoT Section -->
<section
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>"
  class="position-relative py-5"
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Section Title -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Section Paragraphs -->
       <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
