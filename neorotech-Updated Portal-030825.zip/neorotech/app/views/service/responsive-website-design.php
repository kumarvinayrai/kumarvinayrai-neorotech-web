<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-34.jpg';
$bannerHeading = 'Responsive Website Design';
$bannerText    = 'Building Adaptive, Mobile-Friendly Websites to Enhance User Experience and Drive Business Results';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'responsive-website-design',
    'title'        => '<span>Responsive Design</span> for Seamless <span>Multi-Device Experiences</span>',
    'introParas'   => [
        'In today’s mobile-first world, a responsive website is essential. Our responsive website design services ensure your site looks and functions beautifully on any device—from desktops and laptops to tablets and smartphones.',
        'Using fluid grids, flexible images, and CSS media queries, we build websites that automatically adapt to different screen sizes and orientations. This approach improves user engagement, reduces bounce rates, and enhances SEO rankings by meeting Google’s mobile-friendly standards.',
    ]
];
?>
<!-- Responsive Website Design Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">
      
      <!-- Title -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2 
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" 
            class="heading-title my-3"
          >
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Paragraphs --> 
       <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start">
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>


<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
