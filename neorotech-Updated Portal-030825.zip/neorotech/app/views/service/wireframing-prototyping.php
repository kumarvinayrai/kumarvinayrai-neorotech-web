<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-23.jpg';
$bannerHeading = 'Wireframing & Prototyping';
$bannerText    = 'Wireframing and prototyping help visualize a product’s structure and flow, reducing risks before development starts';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'  => 'wireframing-prototyping',
    'title'      => 'Intelligent <span>Wireframing</span> and <span>Prototyping</span> for <span>All Digital Platforms</span>',
    'introParas' => [
        'Wireframing and prototyping are key steps in the design process, allowing us to visualize and test product layouts and functionality, By creating interactive wireframes and prototypes, we can refine user flow, gather feedback, and ensure alignment before development begins and This helps minimize risks and ensures a smoother final product.'
    ]
];
?>
<!-- Wireframing & Prototyping Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Title Column -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          <h2 
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" 
            class="heading-title my-3"
          >
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Description Column --> 
        <?php foreach ($servicesData['introParas'] as $para): ?>
          <p class="mx-auto text-start"><?= htmlspecialchars($para) ?></p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
