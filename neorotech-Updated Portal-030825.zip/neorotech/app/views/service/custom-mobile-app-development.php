<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-27.jpg';
$bannerHeading = 'Custom Mobile App Development';
$bannerText    = 'Unlock Your Business Potential with Tailored Mobile App Development for Seamless User Experience and Growth';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'custom-mobile-app-development',
    'title'        => 'End-to-End <span>IT Services</span> for <span>Web Development</span>',
    'introParas'   => [
        'Our custom mobile app development services cater to businesses with unique requirements that aren’t met by standard solutions. We begin with a thorough understanding of your goals, audience, and processes to design and develop an app that is entirely tailored to your business needs.',
        'From feature design to UI/UX, our custom apps are crafted to align with your brand and deliver a unique value proposition to your users. Whether you need a feature-rich e-commerce app, a productivity tool, or a specialized solution for your industry, our custom approach ensures the app is optimized for your specific objectives.',
    ]
];
?>
<!-- Custom Mobile App Development Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
