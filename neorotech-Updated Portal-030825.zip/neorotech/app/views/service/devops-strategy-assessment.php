<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-18.jpg';
$bannerHeading = 'DevOps Strategy & Assessment';
$bannerText    = 'Streamline workflows and boost productivity with customized DevOps strategies and assessments to improve efficiency';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'devops-strategy-assessment',
    'title'        => 'Effective <span>DevOps Strategy</span> and <span>Performance Assessment</span>',
    'introParas'   => [
        'Our DevOps strategy and assessment services evaluate your current workflows and design tailored strategies to optimize your development and operations processes, We assess bottlenecks, inefficiencies, and opportunities for automation, helping you implement DevOps best practices.',
        ' By aligning teams and automating tasks, we improve productivity, reduce errors, and accelerate time-to-market and our approach ensures that your development pipeline is efficient, collaborative, and scalable, enabling continuous improvement and faster, higher-quality releases.'
    ]
];
?>
<!-- DevOps Strategy & Assessment Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">

      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 

      <!-- Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
