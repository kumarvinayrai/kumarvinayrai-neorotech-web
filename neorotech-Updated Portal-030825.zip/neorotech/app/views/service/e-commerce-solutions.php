<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-08.jpg';
$bannerHeading = 'E-commerce Solutions';
$bannerText    = 'Create tailored e-commerce platforms with seamless checkouts, secure payment gateways, and a user-friendly experience';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'e-commerce-solutions',
    'title'        => 'Boost Your Online Business with <span>E-commerce</span> Solutions',
    'introParas'   => [
        'We build custom e-commerce solutions that provide a seamless and secure shopping experience for your customers. From intuitive navigation to secure payment gateways, our platforms are designed to optimize user experience and drive conversions.',
        'We ensure fast loading times, mobile optimization, and smooth checkout processes to boost sales and customer satisfaction. Whether you’re launching a new store or enhancing an existing one, we help create an e-commerce platform that reflects your brand and meets customer expectations.',
    ]
];
?>
<!-- E-commerce Solutions Section -->
<section 
  id="<?= htmlspecialchars($servicesData['sectionId']) ?>" 
  class="position-relative py-5" 
  aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
>
  <div class="container">
    <div class="row">
      
      <!-- Heading -->
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <header>
          
          <h2
            id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading"
            class="heading-title my-3">
            <?= $servicesData['title'] ?>
          </h2>
        </header> 
      
      <!-- Paragraphs --> 
        <?php foreach ($servicesData['introParas'] as $index => $para): ?>
          <p class="mx-auto text-start"<?= $index === 0 ? ' data-aos="fade-left"' : '' ?>>
            <?= htmlspecialchars($para) ?>
          </p>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
