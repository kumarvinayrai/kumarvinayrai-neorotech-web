<section class="bg-primary-clip" aria-labelledby="banner-heading">
  <div class="container-fluid px-0">
    <div class="row g-0 flex-column flex-lg-row min-vh-75 align-items-stretch">

      <!-- Left Text Column -->
      <div class="col-12 col-lg-6 d-flex flex-column justify-content-center px-3 px-sm-4 px-lg-5 py-4 py-lg-5 text-center text-lg-start">
        <header class="hero-content hero-single w-100" data-aos="fade-right">
          <h1 id="banner-heading" class="hero-title lh-sm display-5 display-lg-3">
            <?= htmlspecialchars($bannerHeading) ?>
          </h1>
        </header>
      </div>

      <!-- Right Image with Overlay Text -->
      <div class="col-12 col-lg-6 d-flex position-relative" data-aos="fade-left" data-aos-delay="150">
        <div class="w-100 flex-grow-1 d-flex zoom-effect position-relative">
          <img
            src="<?= htmlspecialchars($bannerImage) ?>"
            alt="News banner featuring current highlights"
            title="News Banner"
            class="img-fluid w-100 h-100 object-fit-cover clip-img"
            loading="lazy"
            decoding="async"
            style="min-height: 280px; max-height: 600px;"
          >
          <div class="insight-overlay position-absolute top-0 start-0 w-100 h-100 d-flex flex-column align-items-center align-items-lg-start justify-content-center px-3 px-sm-4 px-lg-5 text-center text-lg-start">
            <h2 class="insight-title lh-sm h2 h3-lg mb-0" data-aos="fade-up" data-aos-delay="100">
              <?= htmlspecialchars($bannerText) ?>
            </h2>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>
