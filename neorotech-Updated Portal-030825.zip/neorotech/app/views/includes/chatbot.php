 <?php
require_once __DIR__ . '/../includes/header.php';

$botName = "NtB";
$greetingLine1 = "Hi there 👋";
$greetingLine2 = "I’m <strong>$botName</strong>, your virtual assistant.";
$greetingLine3 = "How can I help you today?";
$chatbotURL = "https://chatbot.neorotech.com/index.php";
?>

<!-- Chatbot Toggle Button -->
<button class="chatbot-toggle btn position-fixed rounded-circle p-0 border-0 shadow"
        aria-label="Open chat with <?= $botName ?>"
        title="Chat with <?= $botName ?>"
        id="chatbotToggle">
  <img src="/assets/images/logo/ntBot.png"
       alt="<?= $botName ?> Icon"
       loading="lazy"
       class="img-fluid rounded-circle w-100 h-100 object-fit-contain pointer-events-none">
</button>

<!-- Chat Widget -->
<div class="chatbot-widget rounded-0 position-fixed bg-white shadow-lg d-flex flex-column d-none"
     id="chatbotWidget"
     aria-hidden="true"
     role="dialog">
  <div class="chatbot-widget__header bg-primary text-white d-flex justify-content-between align-items-center p-2">
    <span class="fw-semibold fs-6 d-flex align-items-center gap-2">
      <div class="rounded-circle overflow-hidden d-flex align-items-center justify-content-center bg-white">
        <img src="/assets/images/logo/ntBot.png"
             alt="<?= $botName ?> Icon"
             loading="lazy"
             class="img-fluid object-fit-contain pointer-events-none chat-bot-icon" />
      </div>
      <?= htmlspecialchars($botName) ?>
    </span>
    <button class="chatbot-close btn btn-sm p-1 d-inline-flex align-items-center justify-content-center text-white bg-transparent border-0"
            id="chatbotClose"
            title="Close chat">
      <i class="fa-solid fa-xmark"></i>
    </button>
  </div>

  <iframe src="<?= htmlspecialchars($chatbotURL) ?>"
          title="Chatbot with <?= $botName ?>"
          class="flex-grow-1 border-0 w-100 h-100"
          allow="microphone; camera"
          loading="lazy"
          referrerpolicy="no-referrer"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups">
  </iframe>
</div>

<!-- Greeting Message -->
<div class="chatbot-greeting alert alert-info alert-dismissible fade position-fixed shadow-sm w-auto small d-none"
     id="chatbotGreeting"
     role="alert">
  <strong><?= $greetingLine1 ?></strong><br>
  <?= $greetingLine2 ?><br>
  <?= $greetingLine3 ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close greeting"></button>
</div>

<!-- Cookie Consent -->
<div class="chatbot-cookie bg-dark text-white text-center py-3 d-none position-fixed w-100"
     id="chatbotCookie"
     role="alert"
     aria-live="polite">
  We use cookies to enhance your experience. By continuing, you accept our cookie policy.
  <button class="btn btn-sm btn-light ms-2" onclick="acceptCookies()">Accept</button>
</div>

<!-- Chatbot Script -->
<script>
  document.addEventListener('DOMContentLoaded', () => {
    const toggleBtn = document.getElementById('chatbotToggle');
    const widget = document.getElementById('chatbotWidget');
    const closeBtn = document.getElementById('chatbotClose');
    const greeting = document.getElementById('chatbotGreeting');
    const cookieBar = document.getElementById('chatbotCookie');

    if (!toggleBtn || !widget) return;

    // Open chatbot
    toggleBtn.addEventListener('click', () => {
      widget.classList.remove('d-none');
      widget.setAttribute('aria-hidden', 'false');
      toggleBtn.classList.add('d-none'); // Hide toggle
    });

    // Close chatbot
    closeBtn?.addEventListener('click', () => {
      widget.classList.add('d-none');
      widget.setAttribute('aria-hidden', 'true');
      toggleBtn.classList.remove('d-none'); // Show toggle
    });

    // Animate bot icon every 8s
    setInterval(() => {
      toggleBtn.classList.add('bot-jump');
      setTimeout(() => toggleBtn.classList.remove('bot-jump'), 600);
    }, 8000);

    // Show greeting message once per session
    if (greeting && !sessionStorage.getItem('chatbotGreetingShown')) {
      greeting.classList.remove('d-none');
      greeting.classList.add('show');
      sessionStorage.setItem('chatbotGreetingShown', 'true');

      setTimeout(() => {
        greeting.classList.remove('show');
        greeting.classList.add('d-none');
      }, 8000);
    }

    // Show cookie bar if not accepted
    if (cookieBar && !document.cookie.includes('cookie_accepted=true')) {
      cookieBar.classList.remove('d-none');
    }
  });

  function acceptCookies() {
    document.cookie = "cookie_accepted=true; path=/; max-age=" + 60 * 60 * 24 * 365;
    document.getElementById('chatbotCookie')?.classList.add('d-none');
  }
</script>


<!-- Styles -->
<!-- Styles -->
<style>
:root {
  /* === Chatbot Responsive Variables (Mobile First) === */

  /* Toggle Button */
  --cb-toggle-size: clamp(2.75rem, 9vw, 4rem);
  --cb-toggle-border: clamp(0.1rem, 0.25vw, 0.125rem);
  --cb-toggle-bottom: clamp(4.5rem, 10vw, 5rem);
  --cb-toggle-right: clamp(0.625rem, 3vw, 0.875rem);

  /* Widget */
  --cb-widget-height: 75vh;
  --cb-widget-maxwidth: 90%;

  /* Font Sizes */
  --cb-font-sm: clamp(0.65rem, 2vw, 0.75rem);
  --cb-font-md: clamp(0.75rem, 2.5vw, 0.875rem);
  --cb-font-lg: clamp(0.85rem, 3vw, 1rem);

  /* Icon */
  --cb-icon-size: clamp(2rem, 6vw, 2.5rem);

  /* Greeting */
  --cb-greeting-bottom: clamp(0.85rem, 3vw, 1rem);
  --cb-greeting-padding: clamp(0.5rem, 2vw, 0.75rem);
  --cb-greeting-radius: clamp(0.4rem, 2vw, 0.5rem);
  --cb-greeting-maxwidth: 90%;

  /* Cookie Bar */
  --cb-cookie-padding: clamp(0.75rem, 3vw, 1rem);

  /* Z-Index */
  --cb-z-toggle: 1060;
  --cb-z-cookie: 1030;
  --cb-z-greeting: 1040;
  --cb-z-widget: 1050;
}

/* === Chatbot Toggle Button === */
.chatbot-toggle.btn {
  bottom: var(--cb-toggle-bottom);
  right: 1rem;
  width: var(--cb-toggle-size);
  height: var(--cb-toggle-size);
  background-color: var(--theme-color);
  border: var(--cb-toggle-border) solid var(--theme-color-primary) !important;
  border-radius: 50%;
  position: fixed;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: var(--cb-z-toggle);
  transition: all 0.2s ease-in-out;
  cursor: pointer;
  outline: none;
}

.chatbot-toggle:hover,
.chatbot-toggle:focus,
.chatbot-toggle:active {
  border-color: var(--theme-color);
  box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
}

/* Toggle Icon */
.chat-bot-icon {
  width: var(--cb-icon-size);
  height: var(--cb-icon-size);
  background-color: var(--theme-color);
}

/* === Chatbot Widget === */
.chatbot-widget {
  position: fixed;
  bottom: 0;
  right: 0;
  width: 100%;
  max-width: 18rem;
  height: var(--cb-widget-height);
  z-index: var(--cb-z-widget);
  background-color: var(--theme-color);
  font-size: var(--cb-font-lg);
  display: flex;
  flex-direction: column;
  transition: all 0.3s ease-in-out;
  border-top-left-radius: 0.75rem;
  border-top-right-radius: 0.75rem;
  overflow: hidden;
}

.chatbot-widget * {
  max-width: 100%; 
  font-size: inherit;
}

/* === Greeting Message === */
.chatbot-greeting {
  position: fixed;
  bottom: var(--cb-greeting-bottom);
  right: var(--cb-toggle-right);
  z-index: var(--cb-z-greeting);
  max-width: var(--cb-greeting-maxwidth);
  font-size: var(--cb-font-md);
  padding: var(--cb-greeting-padding);
  border-radius: var(--cb-greeting-radius);
  background-color: #fff;
  color: #000;
  box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
}

/* === Cookie Consent === */
.chatbot-cookie {
  position: fixed;
  bottom: 0;
  width: 100%;
  padding: var(--cb-cookie-padding);
  text-align: center;
  z-index: var(--cb-z-cookie);
  font-size: var(--cb-font-sm);
  background-color: var(--theme-color);
  color: #fff;
}

/* === Bot Animation === */
@keyframes botJump {
  0%, 40%, 80%, 100% { transform: translateY(0); }
  20% { transform: translateY(-25%); }
  60% { transform: translateY(-15%); }
}

.bot-jump {
  animation: botJump 1.2s ease-in-out;
}

/* === Tablet (≥577px) === */
@media (min-width: 577px) {
  :root { 
    --cb-widget-maxwidth: 60%;
  }

  .chatbot-greeting {
    max-width: 18rem;
    font-size: var(--cb-font-md);
  }

  .chatbot-cookie {
    font-size: var(--cb-font-md);
  }
}
 
</style>


<?php require_once __DIR__ . '/../includes/footer.php'; ?>