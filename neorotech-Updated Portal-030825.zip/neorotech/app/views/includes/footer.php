<?php
if (!defined('BASE_URL')) define('BASE_URL', '/');

$contact = [
  'emailCareer'  => 'career@neorotech.com',
  'emailinfo'    => 'info@neorotech.com',
  'emailSupport' => 'support@neorotech.com',
  'address'      => 'Wellington Business Park-1 Marol, Andheri East, Mumbai-400059.'
];

$quickLinks = [
  ['Home', 'home/home'],
  ['About', 'about/index'],
  ['Services', 'service/web-development/'],
  ['Product', 'product/index'],
  ['Careers', 'careers/index'],
  ['Contact Us', 'contact/index'],
];

$social = [
  'facebook'   => 'https://facebook.com',
  'x-twitter'  => 'https://twitter.com',
  'youtube'    => 'https://www.youtube.com/',
  'linkedin-in' => 'https://www.linkedin.com/',
];
?>
<section class="footer-area pt-5" aria-label="Footer Section">
  <footer class="footer-content">
    <div class="container">
      <div class="row gy-4  lh-base">
        <!-- Company Info -->
        <div id="footerInfoCol" class="col-md-6 col-lg-4 footer-content-box" data-aos="fade-right">
          <a href="<?= BASE_URL ?>" class="footer-logo navbar-brand d-flex align-items-center py-3" aria-label="Neorotech Homepage">
            <h1 class="m-0 d-inline-flex align-items-center h4">
              <img src="/assets/images/logo/logo-light.png"
                alt="Neorotech Light Logo"
                class="logo-light me-2">
              <span class="fw-bold fs-3 text-white">Neorotech</span>
            </h1>
          </a>
          <p class="mb-3">
            Neorotech transforms innovations into growth-driven digital solutions for enterprises, startups, and emerging businesses worldwide.
          </p>
        </div>

        <!-- Quick Links -->
        <div class="col-md-6 col-lg-4" data-aos="fade-up">
          <h2 class="footer-content-title">Quick Links</h2>
          <div class="row">
            <?php
            $half = ceil(count($quickLinks) / 2);
            $chunks = array_chunk($quickLinks, $half);
            ?>
            <?php foreach ($chunks as $chunk): ?>
              <div class="col-6">
                <ul class="footer-list list-unstyled">
                  <?php foreach ($chunk as [$label, $url]): ?>
                    <li class="mb-2">
                      <a href="<?= BASE_URL . $url ?>" aria-label="<?= $label ?>">
                        <i class="fas fa-caret-right me-2" aria-hidden="true"></i><?= $label ?>
                      </a>
                    </li>
                  <?php endforeach; ?>
                </ul>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Contact Us -->
        <div class="col-md-6 col-lg-4" data-aos="fade-up">
          <h2 class="footer-content-title">Contact Us</h2>
          <ul class="footer-contact footer-list list-unstyled">
            <?php foreach ($contact as $key => $value): ?>
              <?php if (str_starts_with($key, 'email')): ?>
                <li class="mb-2 d-flex align-items-center">
                  <i class="fa-solid fa-envelope flex-shrink-0 me-2" aria-hidden="true"></i>
                  <a class="d-inline-block" href="mailto:<?= htmlspecialchars($value) ?>" aria-label="Email <?= $value ?>">
                    <?= htmlspecialchars($value) ?>
                  </a>
                </li>
              <?php endif; ?>
            <?php endforeach; ?>
          </ul>
        </div>

        <!-- Large Screen Contact Info -->
        <div id="footerContactLarge" class="col-12">
          <ul id="footerContactBlock" class="footer-contact list-unstyled d-flex flex-wrap align-items-center">
            <li class="d-flex align-items-center me-4 mb-2">
              <i class="fa-solid fa-location-dot flex-shrink-0 me-2" aria-hidden="true"></i>
              <address class="m-0 d-inline-block fs-6">
                <?= htmlspecialchars($contact['address']) ?>
              </address>
            </li>
            <li class="d-flex align-items-center me-4 mb-2">
              <i class="fa-solid fa-location-dot flex-shrink-0 me-2" aria-hidden="true"></i>
              <address class="m-0 d-inline-block fs-6 text-decoration-line-through">
                Gurgaon | Mumbai | Bangalore
              </address>
            </li>
            <li class="d-flex align-items-center me-4 mb-2">
              <i class="fa-solid fa-house-laptop flex-shrink-0 me-2" aria-hidden="true"></i>
              <span class="fs-6">WFH till Dec 2025</span>
            </li>
          </ul>
        </div>

      </div>
    </div>

    <!-- Copyright -->
    <div class="copyright  lh-base mt-4">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-6 mb-3 mb-md-0" data-aos="fade-up">
            <p class="m-0 copyright-text">
              &copy; <?= date('Y') ?> Neorotech Solutions Pvt. Ltd. All Rights Reserved.<br>
              Powered by <a href="<?= BASE_URL ?>" aria-label="Visit Neorotech homepage">Neorotech Solutions Pvt. Ltd.</a>
            </p>
          </div>
          <div class="col-md-6 d-flex justify-content-md-end justify-content-center" data-aos="fade-up" data-aos-delay="100">
            <ul class="footer-social list-inline d-flex gap-3 mb-0">
              <?php foreach ($social as $icon => $url): ?>
                <li class="list-inline-item">
                  <a href="<?= $url ?>" target="_blank" rel="noopener" aria-label="<?= ucfirst(str_replace('-', ' ', $icon)) ?>">
                    <i class="fa-brands fa-<?= $icon ?>" aria-hidden="true"></i>
                  </a>
                </li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </footer>

  <!-- Chatbot -->
  <?php require_once __DIR__ . '/chatbot.php'; ?>

  <!-- Scroll to Top -->
  <a href="#" id="scroll-top" class="scroll-top position-fixed bottom-0 end-0 m-3" aria-label="Scroll to top">
    <i class="fa-solid fa-arrow-up" aria-hidden="true"></i>
  </a>
</section>


<!-- Footer Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js" defer></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js" defer></script>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
      duration: 800,
      once: true,
      mirror: false,
      easing: 'ease-in-out'
    });

    // Scroll-to-top toggle
    const scrollBtn = document.getElementById('scroll-top');
    window.addEventListener('scroll', () => {
      scrollBtn.classList.toggle('active', window.scrollY > 300);
    });

    // Sticky navbar (if present)
    const nav = document.getElementById('navbar');
    if (nav) {
      window.addEventListener('scroll', () => {
        nav.classList.toggle('fixed-top', window.scrollY > 0);
      }, {
        passive: true
      });
    }

    // Responsive footer contact block movement
    const footerInfoCol = document.getElementById('footerInfoCol');
    const footerContactLarge = document.getElementById('footerContactLarge');
    const contactBlock = document.getElementById('footerContactBlock');

    function moveFooterContact() {
      const isMobile = window.innerWidth < 992;
      if (isMobile && !footerInfoCol.contains(contactBlock)) {
        footerInfoCol.appendChild(contactBlock);
      } else if (!isMobile && !footerContactLarge.contains(contactBlock)) {
        footerContactLarge.appendChild(contactBlock);
      }
    }

    moveFooterContact();
    window.addEventListener('resize', moveFooterContact);
  });
</script>
</body>