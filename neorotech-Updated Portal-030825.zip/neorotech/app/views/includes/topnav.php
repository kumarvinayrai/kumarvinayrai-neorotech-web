<section class="d-none d-xl-block" aria-label="Top Contact Info">
  <div class="header-top py-2 bg-light border-bottom">
    <div class="container">
      <div class="row align-items-center">

        <!-- Left: Contact Info -->
        <div class="col-lg-9">
          <ul class="list-unstyled d-flex flex-wrap align-items-center mb-0">
            <li class="me-4 d-flex align-items-center">
              <a href="#" class="text-decoration-none" aria-label="Company Address">
                <i class="fa-solid fa-location-dot me-2" aria-hidden="true"></i>
                <span>Wellington Business Park-1, Andheri East, Mumbai-400059</span>
              </a>
            </li>
            <li class="me-4 d-flex align-items-center">
              <a href="mailto:support@neorotech.com" class="text-decoration-none" aria-label="Email Neorotech">
                <i class="fa-solid fa-envelope me-2" aria-hidden="true"></i>
                <span>support@neorotech.com</span>
              </a>
            </li>
            <li class="d-flex align-items-center">
              <a href="tel:+919819956751" class="text-decoration-none" aria-label="Call Neorotech">
                <i class="fa-solid fa-phone-volume me-2" aria-hidden="true"></i>
                <span>+91 9819956751</span>
              </a>
            </li>
          </ul>
        </div>

        <!-- Right: Social Links -->
        <div class="col-lg-3">
          <div class="d-flex justify-content-lg-end align-items-center gap-3">
            <a href="https://facebook.com" target="_blank" rel="noopener" aria-label="Facebook">
              <i class="fa-brands fa-facebook" aria-hidden="true"></i>
            </a>
            <a href="https://x.com" target="_blank" rel="noopener" aria-label="X (Twitter)">
              <i class="fa-brands fa-x-twitter" aria-hidden="true"></i>
            </a>
            <a href="https://instagram.com" target="_blank" rel="noopener" aria-label="Instagram">
              <i class="fa-brands fa-instagram" aria-hidden="true"></i>
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener" aria-label="LinkedIn">
              <i class="fa-brands fa-linkedin" aria-hidden="true"></i>
            </a>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>
