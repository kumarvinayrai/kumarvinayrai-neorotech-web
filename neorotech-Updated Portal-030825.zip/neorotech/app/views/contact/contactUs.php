<?php
$sectionTitle = 'We’re <span>Here </span>to <span>Help </span>You';
$sectionDescription = 'Got a project in mind? We’d love to hear about it. Fill out the form below and let’s talk.';
$contactAddress = 'Wellington Business Park-1, Marol, Andheri East, Mumbai-400059.';
$contactEmail = 'contact@neorotech.com';
$mapQuery = urlencode($contactAddress);

$success = '';
$error = '';
$input = ['name' => '', 'email' => '', 'phone' => '', 'subject' => '', 'message' => ''];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  foreach ($input as $key => &$value) {
    $value = trim($_POST[$key] ?? '');
  }

  if ($input['name'] && filter_var($input['email'], FILTER_VALIDATE_EMAIL) && $input['phone'] && $input['subject'] && $input['message']) {
    $success = "Thank you, {$input['name']}! Your message has been sent successfully.";
  } else {
    $error = "Please fill out all fields correctly.";
  }
}
?>

<section id="contactUs" class="bg-primary" aria-labelledby="contact-heading">
  <div class="container py-5">
    <header class="mb-4">
      <h2 id="contact-heading" class="heading-title my-3"><?= $sectionTitle ?></h2>
      <p><?= htmlspecialchars($sectionDescription) ?></p>
    </header>

    <div class="row gy-4">
      <!-- Contact Info -->
      <aside class="col-md-4" aria-labelledby="contact-info-heading">
        <h3 id="contact-info-heading" class="visually-hidden">Contact Information</h3>
        <ul class="list-unstyled">
          <li class="mb-4">
            <h6 class="mb-1">Address</h6>
            <p class="text-start"><?= htmlspecialchars($contactAddress) ?></p>
          </li>
          <li>
            <h6 class="mb-1">Email Address</h6>
            <p class="text-start">
              <a href="mailto:<?= htmlspecialchars($contactEmail) ?>" class="text-decoration-none">
                <?= htmlspecialchars($contactEmail) ?>
              </a>
            </p>
          </li>
        </ul>
      </aside>

      <!-- Contact Form -->
      <div class="col-md-8">
        <form method="post" action="#contactUs" class="needs-validation" novalidate aria-labelledby="contact-form-heading">
          <h3 id="contact-form-heading" class="visually-hidden">Contact Form</h3>
          <div class="row g-3">
            <?php
            $fields = [
              ['type' => 'text', 'name' => 'name', 'placeholder' => 'Your Name', 'autocomplete' => 'name', 'validation' => 'Please enter your name.'],
              ['type' => 'email', 'name' => 'email', 'placeholder' => 'Email Address', 'autocomplete' => 'email', 'validation' => 'Please enter a valid email address.'],
              ['type' => 'tel', 'name' => 'phone', 'placeholder' => 'Phone Number', 'autocomplete' => 'tel', 'validation' => 'Please enter your phone number.'],
              ['type' => 'text', 'name' => 'subject', 'placeholder' => 'Subject', 'autocomplete' => 'off', 'validation' => 'Please enter a subject.'],
            ];
            foreach ($fields as $field): 
              $value = htmlspecialchars($input[$field['name']]);
            ?>
              <div class="col-md-6">
                <input
                  type="<?= $field['type'] ?>"
                  name="<?= $field['name'] ?>"
                  class="form-control"
                  value="<?= $value ?>"
                  placeholder="<?= $field['placeholder'] ?>"
                  autocomplete="<?= $field['autocomplete'] ?>"
                  required
                  aria-label="<?= $field['placeholder'] ?>"
                  aria-invalid="<?= empty($value) ? 'true' : 'false' ?>">
                <div class="invalid-feedback"><?= $field['validation'] ?></div>
              </div>
            <?php endforeach; ?>

            <div class="col-12">
              <textarea
                name="message"
                class="form-control"
                rows="5"
                placeholder="Write a message"
                autocomplete="off"
                required
                aria-label="Message"
                aria-invalid="<?= empty($input['message']) ? 'true' : 'false' ?>"><?= htmlspecialchars($input['message']) ?></textarea>
              <div class="invalid-feedback">Please enter your message.</div>
            </div>

            <div class="col-12 text-end">
              <button type="submit" class="btn theme-btn" aria-label="Submit your message">Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- TOAST NOTIFICATION -->
<?php if ($success || $error): ?>
  <div class="position-fixed top-0 start-50 translate-middle-x p-3" style="z-index:1080">
    <?php $toastClass = $success ? 'bg-success' : 'bg-danger'; ?>
    <div id="liveToast" class="toast align-items-center text-white <?= $toastClass ?> border-0 show" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body"><?= htmlspecialchars($success ?: $error, ENT_QUOTES, 'UTF-8') ?></div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- VALIDATION SCRIPT -->
<script>
(() => {
  'use strict';
  const forms = document.querySelectorAll('.needs-validation');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    });
  });

  document.addEventListener('DOMContentLoaded', () => {
    const toastEl = document.getElementById('liveToast');
    if (toastEl) {
      new bootstrap.Toast(toastEl, { autohide: true, delay: 5000 }).show();
    }
  });
})();
</script>
