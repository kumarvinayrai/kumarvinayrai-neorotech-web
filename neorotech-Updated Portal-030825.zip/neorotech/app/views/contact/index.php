<?php
$bannerImage = '/assets/images/banner/banner.jpg';
$bannerHeading = 'Contact us';
$bannerText = 'Have a question or need assistance? Contact us now, and we’ll get back to you promptly!';
$contactAddress = 'Wellington Business Park-1, Marol, Andheri East, Mumbai-400059.';
$mapQuery = urlencode($contactAddress);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';
?>

<main>
  <?php 
require_once __DIR__ . '/../home/partner.php';
require_once __DIR__ . '/contactUs.php'; ?>

  <!-- MAP SECTION -->
  <section aria-label="Location Map" class="pt-0">
    <div class="container-fluid">
      <div class="row">
        <article class="ratio ratio-16x9 overflow-hidden">
          <iframe
            src="https://www.google.com/maps?q=<?= $mapQuery ?>&output=embed"
            title="Map of <?= htmlspecialchars($contactAddress) ?>"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
            class="border-0"
            allowfullscreen></iframe>
        </article>
      </div>
    </div>
  </section>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
