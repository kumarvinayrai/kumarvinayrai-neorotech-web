<?php
// job_data.php
declare(strict_types=1);

/**
 * Get all available job positions.
 * Useful for dropdown suggestions or search autocomplete.
 *
 * @return string[]
 */
function getJobPositions(): array {
    return [
        '.Net Developer',
        'Business Analyst',
        'Business Development - IT',
        'Chief of Staff',
        'Database Developer',
        'HTML Developer',
        'Marketing - Content Writer',
        'PHP Developer',
        'Python Developer',
        'QA Engineer',
        'Senior Business Analyst',
        'Senior DBA',
        'Senior PHP Developer',
        'Senior QA Engineer',
        'Technical ',
        'WordPress Developer',
    ];
}

/**
 * Get currently open job roles with type and experience details.
 *
 * @return array<int, array{
 *     type: string,
 *     title: string,
 *     experience: string
 * }>
 */
function getCurrentOpenings(): array {
    return [
        [
            'type' => 'Full Time',
            'title' => 'WordPress Developer',
            'experience' => 'Experience 4+ Years',
        ],
        [
            'type' => 'Full Time',
            'title' => 'Business Analyst',
            'experience' => 'Experience 2 - 4 years',
        ],
        [
            'type' => 'Full Time',
            'title' => 'Chief of Staff',
            'experience' => 'Experience 5 - 10 years',
        ],
        [
            'type' => 'Full Time',
            'title' => 'Business Development - IT',
            'experience' => 'Experience 4 - 12 years',
        ],
    ];
}
