<?php
declare(strict_types=1);

// Banner data
$bannerImage = '/assets/images/career/career-02.jpg';
$bannerHeading = 'Shape your future in tech with us';
$bannerText = 'Accelerate your career in tech experience with meaningful innovation, growth, and ership in global software development';

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Positions & response handling
$positions = ['Developer', 'Designer', 'Project Manager', 'QA Tester'];
$success = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $city     = trim($_POST['city'] ?? '');
    $position = trim($_POST['position'] ?? '');
    $message  = trim($_POST['message'] ?? '');
    $resume   = $_FILES['resume'] ?? null;

    $allowedMimeTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    $allowedExtensions = ['pdf', 'doc', 'docx'];

    if (!$name || !$email || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$phone || !$city || !$position || !$message) {
        $error = "Please fill out all fields correctly.";
    } elseif (!$resume || $resume['error'] !== UPLOAD_ERR_OK) {
        $error = "Please upload your resume file.";
    } else {
        $mimeTypeValid = false;
        $extensionValid = false;

        if (class_exists('finfo')) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->file($resume['tmp_name']);
            $mimeTypeValid = in_array($mimeType, $allowedMimeTypes);
        }

        $extension = strtolower(pathinfo($resume['name'], PATHINFO_EXTENSION));
        $extensionValid = in_array($extension, $allowedExtensions);

        if (!$mimeTypeValid && !$extensionValid) {
            $error = "Invalid resume file type. Please upload a PDF or Word document.";
        } else {
            $uploadDir = __DIR__ . '/../uploads/resumes/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $fileName = time() . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', basename($resume['name']));
            $targetPath = $uploadDir . $fileName;

            if (move_uploaded_file($resume['tmp_name'], $targetPath)) {
                $success = "Thank you, $name! Your application has been received.";
            } else {
                $error = "File upload failed. Please try again.";
            }
        }
    }
}
?>
<main>
  <section id="sh-apply-job" class="py-5" aria-labelledby="sh-apply-job-heading">
    <div class="container">

      <!-- Section Heading -->
      <div class="row mb-4">
        <div class="col-12 text-center" data-aos="fade-up">
          <h2 id="sh-apply-job-heading" class="heading-title my-3">
            <span>Upskill</span> with Us to Build Your <span>Digital Edge</span>
          </h2>
          <p class="apply-subtitle">
            Email your CV to <a href="mailto:hr@neorotech.com">hr@neorotech.com</a>
          </p>
        </div>
      </div>

      <!-- Application Form -->
      <div class="row">
        <div class="col-12">
          <form action="#sh-apply-job" method="POST" enctype="multipart/form-data"
                class="needs-validation" novalidate data-aos="fade-up">
            <div class="row g-3">

              <div class="col-md-6">
                <input type="text" name="name" class="form-control" placeholder="Name" required>
                <div class="invalid-feedback">Please enter your name.</div>
              </div>

              <div class="col-md-6">
                <input type="email" name="email" class="form-control" placeholder="E-Mail" required>
                <div class="invalid-feedback">Please enter a valid email address.</div>
              </div>

              <div class="col-md-4">
                <input type="text" name="phone" class="form-control" placeholder="Phone Number" required>
                <div class="invalid-feedback">Please enter your phone number.</div>
              </div>

              <div class="col-md-4">
                <input type="text" name="city" class="form-control" placeholder="City" required>
                <div class="invalid-feedback">Please enter your city.</div>
              </div>

              <div class="col-md-4">
                <select name="position" class="form-select" required>
                  <option value="" disabled selected>- Position Applying For -</option>
                  <?php foreach ($positions as $pos): ?>
                    <option value="<?= htmlspecialchars($pos) ?>"><?= htmlspecialchars($pos) ?></option>
                  <?php endforeach; ?>
                </select>
                <div class="invalid-feedback">Please select a position.</div>
              </div>

              <div class="col-12">
                <textarea name="message" class="form-control" rows="4"
                          placeholder="Your Message Here" required></textarea>
                <div class="invalid-feedback">Please enter your message.</div>
              </div>

              <div class="col-12">
                <label for="resume" class="form-label">Upload Your Resume *</label>
                <input type="file" name="resume" id="resume"
                       class="form-control" required accept=".pdf,.doc,.docx">
                <div class="invalid-feedback">Please upload your resume.</div>
              </div>

              <div class="col-12 text-center">
                <button type="submit" class="theme-btn btn">Submit</button>
              </div>
            </div>

            <!-- Hidden Metadata Fields -->
            <input type="hidden" name="form_id" value="563">
            <input type="hidden" name="form_name" value="Careers">
            <input type="hidden" name="form_url" value="https://neorotech.com/careers/">
          </form>
        </div>
      </div>

    </div>
  </section>

  <!-- Success/Error Toast -->
  <?php if ($success || $error): ?>
    <div class="position-fixed top-0 start-50 translate-middle-x p-3" style="z-index: 1080;">
      <?php $toastClass = $success ? 'bg-success' : 'bg-danger'; ?>
      <div id="liveToast"
           class="toast align-items-center text-white border-0 show <?= $toastClass ?>"
           role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
          <div class="toast-body">
            <?= htmlspecialchars($success ?: $error, ENT_QUOTES, 'UTF-8') ?>
          </div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto"
                  data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
      </div>
    </div>
  <?php endif; ?>
</main>



<?php include __DIR__ . '/../includes/footer.php'; ?>

<!-- Form Validation & Toast Handling -->
<script>
(() => {
  'use strict';

  // Bootstrap validation
  const forms = document.querySelectorAll('.needs-validation');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    });
  });

  // Show Toast if exists
  document.addEventListener('DOMContentLoaded', () => {
    const toastEl = document.getElementById('liveToast');
    if (toastEl) {
      const toast = new bootstrap.Toast(toastEl, { autohide: true, delay: 5000 });
      toast.show();
    }
  });
})();
</script>

