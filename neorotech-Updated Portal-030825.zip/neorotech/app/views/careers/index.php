<?php
require_once __DIR__ . '/jobData.php';

// --- PROCESS JOB SEARCH ---
$searchTerm = $_GET['keywords'] ?? null;
$alertMessage = null;

if ($searchTerm !== null) {
  $searchTerm = trim($searchTerm);
  $openings = getCurrentOpenings();
  $matched = array_filter(
    $openings,
    fn($job) =>
    stripos($job['title'], $searchTerm) !== false
  );

  if (!empty($matched)) {
    header('Location: currentOpenings');
    exit;
  } else {
    $alertMessage = 'Currently we don’t have an open position for the related skillset.';
  }
}

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';

$data = [
  'hero' => [
    'title' => '<span>Careers</span> at <span>Neorotech</span>',
    'description' => 'Shape smarter futures with Neorotech by solving challenges through technology.',
    'search_placeholder' => 'Enter your keyword here',
    'search_button' => 'Search Jobs',
    'image' => [
      'src' => '/assets/images/career/career-01.jpg',
      'alt' => 'Team of professionals at Neorotech working together in an office'
    ]
  ],
  'contentSections' => [
    [
      'heading' => '<span>Innovating</span> Business Through <span>Strategic</span> Software <span>Intelligence</span>',
      'description' => 'Driving business transformation through intelligent, strategy-driven software solutions, we enable growth with innovative and insightful approaches while empowering enterprises with cutting-edge software intelligence for a lasting strategic advantage.',
      'image' => [
        'src' => '/assets/images/banner/bg-01.jpg',
        'alt' => 'Careers campus talent program'
      ],
      'aos' => [
        'section' => 'fade-up',
        'text' => 'fade-right',
        'image' => 'zoom-in',
        'delay' => 200
      ]
    ]
  ],
  'perks' => [
    '5 Days Working Per Week',
    'Open Work Culture',
    'Performance Appreciation Bonus & Rewards',
    'Employee Upskill Programs',
    'Employee Friendly Leave Policies',
    'Software Training',
  ],
  'callToAction' => [
    'heading' => 'Careers at <span>Neorotech</span>',
    'label' => 'SEARCH AND APPLY',
    'link' => 'currentOpenings',
    'iconClass' => 'fa-solid fa-arrow-right-long ms-2'
  ],
  'communities' => [
    ['title' => 'Talent community', 'link' => 'applyJob'],
    ['title' => 'Campus communities', 'link' => 'applyJob'],
    ['title' => 'Freelance consultants', 'link' => 'applyJob']
  ]
];
?>
<!-- HERO SECTION -->
<section class="bg-primary-clip" aria-labelledby="careers-heading">
  <div class="container-fluid px-0">
    <div class="row g-0 flex-column flex-lg-row align-items-stretch min-vh-75">

      <!-- Left Text Column -->
      <div class="col-12 col-lg-6 d-flex flex-column justify-content-center px-3 px-sm-4 px-lg-5 py-4 py-lg-5">
        <header class="hero-content hero-single w-100 text-center text-lg-start" data-aos="fade-right">
          <h1 id="careers-heading" class="hero-title lh-sm display-5 display-lg-3">
            <?= $data['hero']['title'] ?>
          </h1>
        </header>
      </div>

      <!-- Right Image + Overlay Text + Search -->
      <div class="col-12 col-lg-6 d-flex position-relative" data-aos="fade-left" data-aos-delay="150">
        <div class="position-relative w-100 flex-grow-1 d-flex zoom-effect">
          <img
            src="<?= $data['hero']['image']['src'] ?>"
            alt="<?= $data['hero']['image']['alt'] ?>"
            class="img-fluid w-100 h-100 object-fit-cover clip-img"
            loading="lazy"
            decoding="async"
            style="min-height: 280px; max-height: 600px;"
          >
          <div class="insight-overlay position-absolute top-0 start-0 w-100 h-100 d-flex flex-column align-items-center align-items-lg-start justify-content-center px-3 px-sm-4 px-lg-5 text-center text-lg-start">
            <h2 class="insight-title lh-sm h2 h3-lg py-4" data-aos="fade-up" data-aos-delay="100">
              <?= $data['hero']['description'] ?>
            </h2>
            <form method="get" class="row g-2 w-100 justify-content-center justify-content-lg-start" role="search" aria-label="Job Search Form">
              <div class="col-12 col-md-7">
                <label for="job-search" class="visually-hidden">Search job keywords</label>
                <input
                  type="text" name="keywords" id="job-search"
                  class="form-control"
                  placeholder="<?= htmlspecialchars($data['hero']['search_placeholder']) ?>"
                  autocomplete="off"
                  required
                >
              </div>
              <div class="col-12 col-md-5 d-grid">
                <button type="submit" class="btn theme-btn py-2">
                  <?= htmlspecialchars($data['hero']['search_button']) ?>
                  <i class="fas fa-arrow-right-long ms-2" aria-hidden="true"></i>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>


<!-- CONTENT BLOCKS -->
<?php foreach ($data['contentSections'] as $index => $section): ?>
  <section class="py-5" aria-labelledby="section-heading-<?= $index ?>" data-aos="<?= $section['aos']['section'] ?>">
    <div class="container">
      <div class="row align-items-center g-5  lh-base">
        <div class="col-lg-6" data-aos="<?= $section['aos']['text'] ?>">
          <header>
            <h2 id="section-heading-<?= $index ?>" class="heading-title my-3"><?= $section['heading'] ?></h2>
          </header>
          <p><?= $section['description'] ?></p>
        </div>
        <div class="col-lg-6">
          <figure class="zoom-effect mb-4 ms-xl-5" data-aos="<?= $section['aos']['image'] ?>" data-aos-delay="<?= $section['aos']['delay'] ?>">
            <img
              src="<?= $section['image']['src'] ?>"
              alt="<?= $section['image']['alt'] ?>"
              class="img-fluid rounded-0 shadow-sm"
              loading="lazy" decoding="async">
          </figure>
        </div>
      </div>
    </div>
  </section>
<?php endforeach; ?>

<!-- PERKS SECTION -->
<section class="py-5 bg-primary" aria-label="Life at Neorotech" data-aos="fade-up">
  <div class="container">
    <div class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <h2 class="heading-title my-3">Life at <span>Neorotech</span> Solution</h2>
        <p class="mx-auto text-start">
          At the core of our approach is intelligent, strategy-driven software that transforms businesses,
          fosters growth through innovation, and empowers enterprises with forward-thinking software intelligence.
        </p>
      </div>
    </div>
    <div class="row g-4">
      <?php foreach ($data['perks'] as $index => $perk): ?>
        <div class="col-12 col-md-6 col-lg-4 d-flex" data-aos="zoom-in" <?= $index ? 'data-aos-delay="' . ($index * 100) . '"' : '' ?>>
          <article class="card theme-card h-100 border-0 rounded-0 p-3 d-flex flex-column w-100 min-vh-75" aria-label="<?= htmlspecialchars($perk) ?>">
            <div class="card-body d-flex flex-column justify-content-center h-100">
              <h3 class="card-title h5 mb-0">
                <?= htmlspecialchars($perk) ?>
              </h3>
            </div>
          </article>
        </div>

      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CALL TO ACTION -->
<section class="py-5 text-center" data-aos="zoom-in">
  <div class="container">
    <h2 class="heading-title my-3"><?= $data['callToAction']['heading'] ?></h2>
    <a href="<?= $data['callToAction']['link'] ?>" class="btn theme-btn" title="<?= $data['callToAction']['label'] ?>">
      <?= $data['callToAction']['label'] ?> <i class="<?= $data['callToAction']['iconClass'] ?>"></i>
    </a>
  </div>
</section>

<!-- COMMUNITIES SECTION -->
<section class="py-5 bg" aria-label="Neorotech Talent Communities" data-aos="fade-up">
  <div class="container">
    <div class="row g-4">
      <?php foreach ($data['communities'] as $index => $community): ?>
        <div class="col-12 col-md-6 col-lg-4 d-flex" data-aos="zoom-in" <?= $index ? 'data-aos-delay="' . ($index * 100 + 200) . '"' : '' ?>>
          <a href="<?= $community['link'] ?>" class="w-100" title="<?= htmlspecialchars($community['title']) ?>">
            <article class="card h-100 border-0 rounded-0 theme-card p-3  lh-base d-flex flex-column justify-content-center align-items-center">
              <h3 class="card-title h5 content-title mb-3"><?= htmlspecialchars($community['title']) ?></h3>
              <span class="btn theme-btn d-inline-flex gap-2">
                Join Us <i class="fas fa-arrow-right-long ms-2"></i>
              </span>
            </article>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<!-- TOAST NOTIFICATION -->
<?php if ($alertMessage): ?>
  <div class="position-fixed top-0 start-50 translate-middle-x p-3" style="z-index:1055">
    <div class="toast align-items-center text-bg-warning border-0 show" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body"><?= htmlspecialchars($alertMessage) ?></div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    </div>
  </div>
  <script>
    const toast = new bootstrap.Toast(document.querySelector('.toast'), {
      delay: 5000
    });
    toast.show();
  </script>
<?php endif; ?>