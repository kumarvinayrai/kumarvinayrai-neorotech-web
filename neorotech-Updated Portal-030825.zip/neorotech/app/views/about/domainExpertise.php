<?php
declare(strict_types=1);

$domainExpertise = [
  'title' => 'Our <span>Expertise</span> and <span>Approach</span> at <span>Neorotech</span>',
];

$domainExpertiseSlides = [
  [
    ['title' => 'Software & Solutions', 'description' => 'Innovative and scalable software solutions designed to meet evolving business needs.'],
    ['title' => 'GenAI', 'description' => 'Embedding intelligence into business with GenAI means using advanced models that generate content or data by learning from existing patterns.'],
    ['title' => 'Banking & Financial Services', 'description' => 'Driving digital transformation in finance through secure, agile platforms.'],
    ['title' => 'Healthcare', 'description' => 'Modernizing healthcare delivery with smart, efficient technology.'],
    ['title' => 'Insurance', 'description' => 'Revolutionizing insurance with automation, analytics, and digital tools.'],
    ],
  [
    ['title' => 'Telecom & Media', 'description' => 'Delivering seamless connectivity and digital content innovation.'],
    ['title' => 'Education', 'description' => 'Enhancing learning through digital transformation and AI-powered platforms.'],
    ['title' => 'Industrial', 'description' => 'Empowering industrial sectors with smart automation and optimized processes.'],
    ['title' => 'Consumer Tech', 'description' => 'Creating intuitive technology solutions for today’s connected consumers.'],
  ],
];
?>

<section id="domain-experties" class="position-relative py-5 bg-primary" aria-labelledby="domainExpertise-heading">
  <div class="container">

    <!-- Section Header -->
    <header class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <h2 id="domainExpertise-heading" class="heading-title my-3">
          <?= $domainExpertise['title'] ?>
        </h2>
        <p class="text-muted ">Explore how Neorotech applies cross-industry expertise to build transformative digital solutions.</p>
      </div>
    </header>

    <!-- Domain Expertise Cards Grid -->
    <section class="tech-driven-section" aria-label="Neorotech Domain Expertise Grid">
      <div class="container">
        <div class="row g-4">
          <?php
          $flatCards = array_merge(...$domainExpertiseSlides);
          foreach ($flatCards as $index => $card):
            $title = htmlspecialchars($card['title']);
            $description = htmlspecialchars($card['description'] ?? '');
          ?>
            <div class="col-12 col-sm-6 col-lg-4" data-aos="zoom-in" data-aos-delay="<?= 100 * ($index + 1) ?>">
              <article class="card theme-card h-100 border-0 rounded-0 p-3 d-flex flex-column" itemscope itemtype="https://schema.org/Service">
                <div class="card-body d-flex flex-column h-100">
                  <h3 class="card-title h5 mb-2" itemprop="name"><?= $title ?></h3>
                  <?php if ($description): ?>
                    <p class="card-text mb-0  lh-base" itemprop="description"><?= $description ?></p>
                  <?php endif; ?>
                </div>
              </article>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </section>

  </div>
</section>
