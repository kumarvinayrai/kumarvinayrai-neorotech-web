<?php

declare(strict_types=1);

// About section content
$aboutText = [
  // 'sectionSubtitle' => 'Future Empowerment',
  'sectionTitle'    => 'Trusted <span>Technology Partner</span> for <span>Scalable</span> and <span>Secure Solutions</span>',
  'description'     => <<<TEXT
    At Neorotech Solutions, we merge visionary thinking with operational precision to help businesses thrive in a rapidly evolving digital landscape and we deliver Advanced Technology Solutions™ and Core Business Services that drive measurable impact—enabling enterprises to scale smarter, respond faster, and  confidently. 
    From AI-powered platforms and hyperautomation to IoT-integrated systems, cloud modernization, and zero-trust cybersecurity frameworks, we design intelligent systems that redefine enterprise performance.
    We believe in building long-lasting partnerships with our clients. We take the time to understand your unique needs and challenges, and we collaborate closely to develop tailored solutions that deliver tangible results. Our dedicated team of experts is committed to providing exceptional service and consistently exceeding expectations.
    We don’t just imagine the future—we build, secure, and deliver it.
TEXT,
];

// Tech highlights title
$featureHighlight = [
  'title' => 'Tech Highlights',
];

// Tech highlights list
$techHighlights = [
  [
    'title'       => 'Data Intelligence & Analytics',
    'description' => 'Unlock actionable insights through advanced data mining, visualization, and real-time business intelligence platforms.',
  ],
  [
    'title'       => 'Blockchain Integration',
    'description' => 'Enable trusted digital transactions, traceability, and decentralized architectures using enterprise-grade blockchain technology.',
  ],
  [
    'title'       => 'Sustainable IT Solutions',
    'description' => 'Reduce environmental impact with energy-efficient architectures, green cloud practices, and carbon-conscious infrastructure.',
  ],

  [
    'title'       => 'Low-Code/No-Code Solutions',
    'description' => 'Empower business users to build scalable applications quickly with visual development tools and minimal coding.',
  ],
  [
    'title' => 'AI-powered Enterprise Solutions',
    'description' => 'AI-driven systems for automation, prediction, and business decision intelligence.',
  ],
  [
    'title' => 'End-to-End Hyperautomation',
    'description' => 'Automate workflows and tasks using advanced orchestration and RPA.',
  ],
  [
    'title' => 'IoT System Integration',
    'description' => 'Enable real-time device communication and connected infrastructure with insights.',
  ],
  [
    'title' => 'Cloud-Native Transformation',
    'description' => 'Transform legacy systems with scalable, modern cloud-native architectures efficiently.',
  ],
  [
    'title' => 'Zero-Trust Cybersecurity',
    'description' => 'Ensure secure access with identity checks and constant threat monitoring.',
  ],
];
?>
<section id="about" class="position-relative py-5 bg" aria-labelledby="about-heading">
  <div class="container">

    <!-- Section Header -->
    <div class="row">
      <div class="col-12 text-center mb-4" data-aos="fade-up">
        <!-- <span class="sub-heading-title d-inline-block mb-2">
          <= htmlspecialchars($aboutText['sectionSubtitle']) ?>
        </span> -->
        <h2 id="about-heading" class="heading-title my-3">
          <?= $aboutText['sectionTitle'] ?>
        </h2>
        <p class="mx-auto text-start">
          <?= nl2br(htmlspecialchars($aboutText['description'])) ?>
        </p>
      </div>
    </div>

    <!-- Tech Highlights Section -->
    <section id="aboutHighlights" class="tech-driven-section mt-4" aria-label="Tech Highlights">
      <div class="container">
        <div class="row g-4">
          <?php foreach ($techHighlights as $itemIndex => $card): ?>
            <div class="col-12 col-sm-6 col-lg-4" data-aos="zoom-in" data-aos-delay="<?= 100 * ($itemIndex + 1) ?>">
              <article class="card theme-card h-100 border-0 rounded-0 p-3 d-flex flex-column">
                <div class="card-body d-flex flex-column h-100">
                  <h3 class="card-title h5 mb-2">
                    <?= htmlspecialchars($card['title']) ?>
                  </h3>
                  <p class="card-text mb-0  lh-base">
                    <?= htmlspecialchars($card['description']) ?>
                  </p>
                </div>
              </article>
            </div>

          <?php endforeach; ?>
        </div>
      </div>
    </section>

  </div>
</section>