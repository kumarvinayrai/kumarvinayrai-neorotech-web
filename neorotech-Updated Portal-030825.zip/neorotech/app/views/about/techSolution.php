<?php
declare(strict_types=1);

$techDrivenSection = [
  // 'subtitle'    => 'Driven by Technology, Built with Purpose',
  'title'       => 'How We <span>Work</span> at <span>Neorotech</span> Solution',
  'description' => 'We harness cutting-edge technology, data insights, and human-centered thinking to deliver agile, future-ready solutions that fuel business growth and societal impact.',
];

$techDrivenSlides = [
  [ 
    [
      'title'       => 'Philosophy of Purpose',
      'description' => 'Our philosophy blends innovation with intent—driving meaningful results while upholding transparency and trust.', 
    ],
    [
      'title'       => 'Agile & Adaptive Methods',
      'description' => 'We move with speed and precision, adapting to market shifts while delivering consistent, high-quality solutions.', 
    ],
    [
      'title'       => 'Client-Centric Collaboration',
      'description' => 'Our solutions are born from deep listening, collaborative discovery, and a commitment to exceeding expectations.', 
    ],
  ],
  [
    [
      'title'       => 'Data-Driven Innovation',
      'description' => 'We extract powerful insights from data to create smarter, scalable strategies that unlock growth potential.', 
    ],
    [
      'title'       => 'Ethical Engineering',
      'description' => 'We integrate integrity and accountability into our development lifecycle to ensure responsible tech delivery.', 
    ],
    [
      'title'       => 'Future-Focused Delivery',
      'description' => 'Our teams remain ahead of the curve—embracing AI, automation, and cloud-native tools to drive impact.',
    ],
  ],
];
?>
<section id="techDriven" class="position-relative py-5 bg" aria-labelledby="techDriven-heading">
  <div class="container">

    <!-- Section Header -->
    <div class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <!-- <span class="sub-heading-title d-inline-block mb-2">
          <= htmlspecialchars($techDrivenSection['subtitle']) ?>
        </span> -->
        <h2 id="techDriven-heading" class="heading-title my-3">
          <?= $techDrivenSection['title'] ?>
        </h2>
        <p class="mx-auto text-start">
          <?= htmlspecialchars($techDrivenSection['description']) ?>
        </p>
      </div>
    </div>

    <!-- Tech-Driven Cards -->
    <section id="techDrivenSection" class="tech-driven-section" aria-label="Tech-driven philosophy">
      <div class="container">
        <div class="row g-4">
          <?php
          $flatCards = array_merge(...$techDrivenSlides);
          foreach ($flatCards as $index => $card): ?>
            <div class="col-12 col-sm-6 col-lg-4" data-aos="zoom-in" data-aos-delay="<?= 100 * ($index + 1) ?>">
              <article class="card theme-card h-100 border-0 rounded-0 p-3 d-flex flex-column">
                <div class="card-body d-flex flex-column h-100">
                  <h3 class="card-title h5 mb-2">
                    <?= htmlspecialchars($card['title']) ?>
                  </h3>
                  <p class="card-text mb-0  lh-base">
                    <?= htmlspecialchars($card['description']) ?>
                  </p>
                </div>
              </article>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </section>

  </div>
</section>



