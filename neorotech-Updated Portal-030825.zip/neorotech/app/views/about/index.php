<?php
$bannerImage = '/assets/images/about/about-02.jpg';
$bannerHeading = 'Transforming Technology Into Business Value';
$bannerText = 'Every solution we build is strategically aligned to enterprise goals—delivering measurable impact and long-term advantage';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';
require_once __DIR__ . '/techDriven.php';

require_once __DIR__ . '/techSolution.php';
require_once __DIR__ . '/domainExpertise.php';
require_once __DIR__ . '/aboutContent.php';
// require_once __DIR__ . '/teamMember.php';
include __DIR__ . '/../contact/contactUs.php';
require_once __DIR__ . '/../home/partner.php';

include __DIR__ . '/../includes/footer.php';
?> 
<style>
    .partners.bg{
        background-color: var(--theme-txt-light);
    }
</style>