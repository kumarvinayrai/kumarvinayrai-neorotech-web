<?php

declare(strict_types=1);

$techSection = [
  'title'      => 'About <span>Neorotech</span> Solution',
  'description' => [
    'At Neorotech Solutions, we are a trusted partner in Digital Engineering and Enterprise Modernization—blending deep technical expertise with strategic industry insight to help clients stay ahead of the curve and proactively address evolving challenges. Our robust solutions and proven frameworks create lasting competitive advantages, enabling businesses to think beyond today and  with confidence.',
    'We prioritize long-term partnerships, taking the time to understand each client’s unique goals and complexities. Through close collaboration, we craft tailored solutions that deliver measurable outcomes. Backed by a team of seasoned professionals, we are committed to delivering not only exceptional technology but also exceptional service that consistently exceeds expectations.',
  ],
];
?>
<section id="philosophy" class="py-5" aria-labelledby="philosophy-heading">
  <div class="container">

    <!-- Section Intro -->
    <div class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4" data-aos="fade-up">
        <h2 id="philosophy-heading" class="heading-title my-3">
          <?= $techSection['title'] ?>
        </h2>
        <?php foreach ($techSection['description'] as $para): ?>
          <p class="mx-auto text-start"><?= $para ?></p>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>