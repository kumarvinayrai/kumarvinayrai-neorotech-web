<?php

declare(strict_types=1);

// Page Metadata
$bannerImage   = '/assets/images/banner/banner-45.jpg';
$bannerHeading = 'Shaping Digital for Business Clients';
$bannerText    = 'Creating high-performance digital platforms that solve business challenges and unlock new opportunities!';

// Section Content
$sectionTitle    = 'Creating Tailored <span>Digital Solutions</span>';
$sectionSubtitle = 'Explore a curated selection of our web design portfolio, demonstrating strategic digital solutions and measurable outcomes that align with business goals across diverse industries through innovation, precision, and a client-centric approach.';

// Portfolio Items
$portfolioItems = [
  ['image' => '/assets/images/project/pro-1.png', 'alt' => 'NeoroEasySite', 'url' => '#'],
  ['image' => '/assets/images/project/pro-2.png', 'alt' => 'NeowoCare Connect', 'url' => '#'],
  ['image' => '/assets/images/project/pro-3.png', 'alt' => 'Neorotech GenAI', 'url' => '#'],
  ['image' => '/assets/images/project/pro-4.png', 'alt' => 'Neorotech SAMS', 'url' => '#'],
 
];

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';
?>
<!-- Portfolio Section -->
<section id="portfolio" class="position-relative py-5" aria-labelledby="portfolio-heading">
  <div class="container" data-aos="fade-up">

    <!-- Section Heading -->
    <div class="row">
      <div class="col-12 col-sm-10 col-md-8 col-lg-12 mx-auto text-center mb-4">
        <span class="sub-heading-title d-inline-block mb-2">Our Portfolio</span>
        <h2 id="portfolio-heading" class="heading-title my-3"><?= $sectionTitle ?></h2>
        <p class="mx-auto text-start"><?= htmlspecialchars($sectionSubtitle) ?></p>
      </div>
    </div>

    <!-- Portfolio Grid -->
    <div class="row g-4 justify-content-center">
      <?php foreach ($portfolioItems as $index => $item): ?>
        <div class="col-12 col-md-6 col-lg-6 d-flex" data-aos="zoom-in" data-aos-delay="<?= $index * 100 ?>">
          <article class="card h-100 border-0 rounded-0 zoom-effect position-relative overflow-hidden p-0 text-white brightness-90">
            <!-- Image with Brown Overlay -->
            <div class="position-relative w-100">
              <img
                src="<?= htmlspecialchars($item['image']) ?>"
                alt="<?= htmlspecialchars($item['alt']) ?>"
                class="img-fluid w-100 h-100 object-fit-cover"
                loading="lazy"
                decoding="async"> 
            </div> 
          </article>

        </div>
      <?php endforeach; ?>
    </div>

  </div>
</section>

 
<?php include __DIR__ . '/../includes/footer.php'; ?>